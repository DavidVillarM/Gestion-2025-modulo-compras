// src/api/productos.js
const BASE = '/api/Productos';

export async function fetchProductos() {
    const res = await fetch(BASE);
    if (!res.ok) throw new Error('Error cargando productos');
    return res.json();
}

export async function fetchProducto(id) {
    const res = await fetch(`${BASE}/${id}`);
    if (!res.ok) throw new Error('Error cargando producto');
    return res.json();
}

export async function createProducto(prod) {
    const res = await fetch(BASE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(prod),
    });
    if (!res.ok) throw new Error('Error creando producto');
    return res.json();
}

export async function updateProducto(id, prod) {
    const res = await fetch(`${BASE}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...prod, idProducto: id }),
    });
    if (!res.ok) throw new Error('Error actualizando producto');
}

export async function deleteProducto(id) {
    const res = await fetch(`${BASE}/${id}`, { method: 'DELETE' });
    if (!res.ok) throw new Error('Error eliminando producto');
}

