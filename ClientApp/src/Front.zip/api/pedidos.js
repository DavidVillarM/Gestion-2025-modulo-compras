//import axios from './axios'  // tu instancia axios

//export async function fetchPedidos() {
//  const { data } = await axios.get('/pedidos');
//  return data;
//}

//export async function fetchPedido(id) {
//  const { data } = await axios.get(`/pedidos/${id}`);
//  return data;
//}

//export async function createPedido(dto) {
//  const { data } = await axios.post('/pedidos', dto);
//  return data;
//}

//// y si quieres la generaci�n autom�tica:
//export async function generarAuto(idOrden) {
//  const { data } = await axios.post(`/pedidos/${idOrden}/generar-auto`);
//  return data;
//}
// src/api/pedidos.js
const BASE = '/api/pedidos';

export async function fetchPedidos() {
    const res = await fetch(BASE);
    if (!res.ok) throw new Error('Error cargando pedidos finales');
    return await res.json();
}

export async function fetchPedido(id) {
    const res = await fetch(`${BASE}/${id}`);
    if (!res.ok) throw new Error(`Error cargando pedido final ${id}`);
    return await res.json();
}

export async function createPedido(dto) {
    // dto = {
    //   IdOrden,
    //   IdProveedor,
    //   MontoTotal,
    //   FechaPedido,
    //   FechaEntrega,
    //   Estado,
    //   Detalles: [ { IdProducto, Cantidad, Cotizacion, Iva }, ... ]
    // }
    const res = await fetch(BASE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dto)
    });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error creando pedido final: ${text}`);
    }
    return await res.json();
}

export async function deletePedido(id) {
    const res = await fetch(`${BASE}/${id}`, { method: 'DELETE' });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error eliminando pedido final ${id}: ${text}`);
    }
}

export async function generarAuto(idOrden) {
    // POST /api/pedidos/{idOrden}/generar-auto
    const res = await fetch(`${BASE}/${idOrden}/generar-auto`, { method: 'POST' });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error generando pedidos finales para orden ${idOrden}: ${text}`);
    }
    return await res.json(); // retorna lista de pedidos creados
}
