// src/api/presupuestos.js
// Todas las rutas van anidadas bajo /api/ordenes/{ordenId}/presupuestos
const BASE = '/api/ordenes';

export async function fetchPresupuestos(ordenId) {
    const res = await fetch(`${BASE}/${ordenId}/presupuestos`);
    if (!res.ok) throw new Error(`Error cargando cotizaciones para orden ${ordenId}`);
    return await res.json();
}

export async function createPresupuesto(ordenId, dto) {
    // dto = {
    //   IdProveedor,
    //   FechaEntrega,
    //   Subtotal,
    //   Iva5,
    //   Iva10,
    //   Total,
    //   Detalles: [ { IdProducto, Cantidad, Precio, Iva5, Iva10 }, ... ]
    // }
    const res = await fetch(`${BASE}/${ordenId}/presupuestos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dto)
    });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error creando cotizaci�n para orden ${ordenId}: ${text}`);
    }
    return await res.json();
}

export async function updatePresupuesto(ordenId, idPresu, dto) {
    // Mismo dto que create
    const res = await fetch(`${BASE}/${ordenId}/presupuestos/${idPresu}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dto)
    });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error actualizando cotizaci�n ${idPresu}: ${text}`);
    }
}

export async function deletePresupuesto(ordenId, idPresu) {
    const res = await fetch(`${BASE}/${ordenId}/presupuestos/${idPresu}`, { method: 'DELETE' });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error eliminando cotizaci�n ${idPresu}: ${text}`);
    }
}
