//// src/api/ordenes.js
//import axios from './axios';  // asumo que ya tienes configurada tu instancia Axios con baseURL="/api"

//export async function fetchOrdenes() {
//    const { data } = await axios.get('/ordenes');
//    return data;
//}

//export async function fetchOrden(id) {
//    const { data } = await axios.get(`/ordenes/${id}`);
//    return data;
//}

//export async function createOrden(dto) {
//    // dto = { ordenDetalles: [ { idProducto, cantidad }, ... ] }
//    const { data } = await axios.post('/ordenes', dto);
//    return data;
//}

//export async function updateOrden(id, dto) {
//    // dto = { estado: "...", ordenDetalles: [ { idProducto, cantidad }, ... ] }
//    const resp = await axios.put(`/ordenes/${id}`, dto);
//    return resp.data; // (o resp.status)
//}

//export async function deleteOrden(id) {
//    await axios.delete(`/ordenes/${id}`);
//}

//export async function fetchProveedoresParaOrden(id) {
//    const { data } = await axios.get(`/ordenes/${id}/proveedores`);
//    return data; // [{ idProveedor, nombre, ruc }, ...]
//}

// src/api/ordenes.js
const BASE = '/api/ordenes';

export async function fetchOrdenes() {
    const res = await fetch(BASE);
    if (!res.ok) throw new Error('Error cargando las �rdenes');
    return await res.json();
}

export async function fetchOrden(id) {
    const res = await fetch(`${BASE}/${id}`);
    if (!res.ok) throw new Error(`Error cargando la orden ${id}`);
    return await res.json();
}

export async function createOrden(dto) {
    // dto = { Estado, OrdenDetalles: [ { IdProducto, Cantidad }, ... ] }
    const res = await fetch(BASE, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dto)
    });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error creando la orden: ${text}`);
    }
    return await res.json();
}

export async function updateOrden(id, dto) {
    // dto = { Estado, OrdenDetalles: [ { IdProducto, Cantidad }, ... ] }
    const res = await fetch(`${BASE}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(dto)
    });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error actualizando la orden ${id}: ${text}`);
    }
}

export async function deleteOrden(id) {
    const res = await fetch(`${BASE}/${id}`, { method: 'DELETE' });
    if (!res.ok) {
        const text = await res.text();
        throw new Error(`Error eliminando la orden ${id}: ${text}`);
    }
}

export async function fetchProveedoresParaOrden(ordenId) {
    const res = await fetch(`${BASE}/${ordenId}/proveedores`);
    if (!res.ok) throw new Error(`Error cargando proveedores para orden ${ordenId}`);
    return await res.json();
}
