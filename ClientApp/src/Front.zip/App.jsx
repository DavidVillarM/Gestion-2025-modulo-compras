////import React from 'react';
////import { Routes, Route } from 'react-router-dom';

////import { SideBar } from './Components/SideBar.jsx';

////import { ListaProveedores } from './Pages/ListaProveedores.jsx';
////import { FormProveedores } from './Pages/FormProveedores.jsx';
////import { DetallesProveedores } from './Pages/DetallesProveedores.jsx';
////import { Categorias } from './Pages/Categorias.jsx';

////import  ListaProductos from './Pages/ListaProductos.jsx';
////import  FormProductos from './Pages/FormProductos.jsx';

////import  ListaPedidos from './Pages/ListaPedidos.jsx';
////import  FormPedidos  from './Pages/FormPedidos.jsx';

////import { Facturas } from './Pages/Facturas.jsx';
////import Stock from './Pages/Stock.jsx';

////import ListaPresupuestos from './Pages/ListaPresupuestos.jsx'
////import FormPresupuestos from './Pages/FormPresupuestos.jsx'



////import './App.css';

////export default function App() {
////    return (
////        <div className="flex h-screen overflow-hidden">
////            <SideBar />
////            <div className="flex-1 overflow-auto bg-gray-50">
////                <Routes>
////                    {/* PESTA�A STOCK */}
////                    <Route path="/stock" element={<Stock />} />
////                    <Route path="/stock" element={<Stock />}>
////                        <Route path="nuevo" element={<FormPedidos />} />
////                        <Route path=":id" element={<FormPedidos />} />
////                    </Route>


////                    {/* PROVEEDORES */}
////                    <Route path="/proveedores" element={<ListaProveedores />} />
////                    <Route path="/proveedores/nuevo" element={<FormProveedores />} />
////                    <Route path="/proveedores/:id/detalles" element={<DetallesProveedores />} />
////                    <Route path="/proveedores/:id/editar" element={<FormProveedores />} />

////                    {/* PRODUCTOS */}
////                    <Route path="/productos" element={<ListaProductos />} />
////                    <Route path="/productos/nuevo" element={<FormProductos />} />
////                    <Route path="/productos/:id/editar" element={<FormProductos />} />
////                    <Route path="/productos/:id/detalles" element={<FormProductos />} />

////                    {/* PEDIDOS */}
////                    <Route path="/pedidos" element={<ListaPedidos />} />
////                    <Route path="/pedidos/nuevo" element={<FormPedidos />} />
////                    <Route path="/pedidos/:id" element={<FormPedidos />} />

////                    {/* FACTURAS Y CATEGOR�AS */}
////                    <Route path="/facturas" element={<Facturas />} />
////                    <Route path="/categorias" element={<Categorias />} />

////                    {/* HOME */}
////                    <Route path="/" element={<Categorias />} />

////                    {/* Crear nueva cotizaci�n para una orden */}
////                    <Route
////                        path="/presupuestos/nuevo/:ordenId"
////                        element={<FormPresupuestos />}
////                    />

////                    {/* Cargar cotizaciones existentes de un proveedor para esa orden */}
////                    <Route
////                        path="/presupuestos/cargar/:ordenId/:proveedorId"
////                        element={<FormPresupuestos />}
////                    />

////                    {/* Listar todas las cotizaciones de una orden */}
////                    <Route
////                        path="/cotizaciones/:ordenId"
////                        element={<ListaPresupuestos />}
////                    />




////                </Routes>
////            </div>
////        </div>
////    );
////}

//// src/App.jsx
//import React from 'react';
//import { Routes, Route } from 'react-router-dom';

//import { SideBar } from './Components/SideBar.jsx';

//import { ListaProveedores } from './Pages/ListaProveedores.jsx';
//import { FormProveedores } from './Pages/FormProveedores.jsx';
//import { DetallesProveedores } from './Pages/DetallesProveedores.jsx';
//import { Categorias } from './Pages/Categorias.jsx';

//import ListaProductos from './Pages/ListaProductos.jsx';
//import FormProductos from './Pages/FormProductos.jsx';

//import ListaPedidos from './Pages/ListaPedidos.jsx';
//import FormPedidos from './Pages/FormPedidos.jsx';

//import { Facturas } from './Pages/Facturas.jsx';
//import Stock from './Pages/Stock.jsx';

//import ListaPresupuestos from './Pages/ListaPresupuestos.jsx';
//import FormPresupuestos from './Pages/FormPresupuestos.jsx';

//import './App.css';

//export default function App() {
//    return (
//        <div className="flex h-screen overflow-hidden">
//            <SideBar />
//            <div className="flex-1 overflow-auto bg-gray-50">
//                <Routes>
//                    {/* PESTA�A STOCK */}
//                    <Route path="/stock" element={<Stock />} />
//                    {/* Como FormPedidos maneja crear (sin id) y editar (con id) */}
//                    <Route path="/pedidos/nuevo" element={<FormPedidos />} />
//                    <Route path="/pedidos/:id" element={<FormPedidos />} />

//                    {/* PROVEEDORES */}
//                    <Route path="/proveedores" element={<ListaProveedores />} />
//                    <Route path="/proveedores/nuevo" element={<FormProveedores />} />
//                    <Route path="/proveedores/:id/detalles" element={<DetallesProveedores />} />
//                    <Route path="/proveedores/:id/editar" element={<FormProveedores />} />

//                    {/* PRODUCTOS */}
//                    <Route path="/productos" element={<ListaProductos />} />
//                    <Route path="/productos/nuevo" element={<FormProductos />} />
//                    <Route path="/productos/:id/editar" element={<FormProductos />} />
//                    <Route path="/productos/:id/detalles" element={<FormProductos />} />

//                    {/* PEDIDOS */}
//                    <Route path="/pedidos" element={<ListaPedidos />} />

//                    {/* FACTURAS Y CATEGOR�AS */}
//                    <Route path="/facturas" element={<Facturas />} />
//                    <Route path="/categorias" element={<Categorias />} />

//                    {/* HOME */}
//                    <Route path="/" element={<Categorias />} />

//                    {/* Crear nueva cotizaci�n para una orden */}
//                    <Route
//                        path="/presupuestos/nuevo/:ordenId"
//                        element={<FormPresupuestos />}
//                    />

//                    {/* Cargar cotizaciones existentes de un proveedor para esa orden */}
//                    <Route
//                        path="/presupuestos/cargar/:ordenId/:proveedorId"
//                        element={<FormPresupuestos />}
//                    />

//                    {/* Listar todas las cotizaciones de una orden */}
//                    <Route
//                        path="/cotizaciones/:ordenId"
//                        element={<ListaPresupuestos />}
//                    />
//                </Routes>
//            </div>
//        </div>
//    );
//}

//import React from 'react';
//import { Routes, Route } from 'react-router-dom';

//import { SideBar } from './Components/SideBar.jsx';

//import { ListaProveedores } from './Pages/ListaProveedores.jsx';
//import { FormProveedores } from './Pages/FormProveedores.jsx';
//import { DetallesProveedores } from './Pages/DetallesProveedores.jsx';
//import { Categorias } from './Pages/Categorias.jsx';

//import  ListaProductos from './Pages/ListaProductos.jsx';
//import  FormProductos from './Pages/FormProductos.jsx';

//import  ListaPedidos from './Pages/ListaPedidos.jsx';
//import  FormPedidos  from './Pages/FormPedidos.jsx';

//import { Facturas } from './Pages/Facturas.jsx';
//import Stock from './Pages/Stock.jsx';

//import ListaPresupuestos from './Pages/ListaPresupuestos.jsx'
//import FormPresupuestos from './Pages/FormPresupuestos.jsx'



//import './App.css';

//export default function App() {
//    return (
//        <div className="flex h-screen overflow-hidden">
//            <SideBar />
//            <div className="flex-1 overflow-auto bg-gray-50">
//                <Routes>
//                    {/* PESTA�A STOCK */}
//                    <Route path="/stock" element={<Stock />} />
//                    <Route path="/stock" element={<Stock />}>
//                        <Route path="nuevo" element={<FormPedidos />} />
//                        <Route path=":id" element={<FormPedidos />} />
//                    </Route>


//                    {/* PROVEEDORES */}
//                    <Route path="/proveedores" element={<ListaProveedores />} />
//                    <Route path="/proveedores/nuevo" element={<FormProveedores />} />
//                    <Route path="/proveedores/:id/detalles" element={<DetallesProveedores />} />
//                    <Route path="/proveedores/:id/editar" element={<FormProveedores />} />

//                    {/* PRODUCTOS */}
//                    <Route path="/productos" element={<ListaProductos />} />
//                    <Route path="/productos/nuevo" element={<FormProductos />} />
//                    <Route path="/productos/:id/editar" element={<FormProductos />} />
//                    <Route path="/productos/:id/detalles" element={<FormProductos />} />

//                    {/* PEDIDOS */}
//                    <Route path="/pedidos" element={<ListaPedidos />} />
//                    <Route path="/pedidos/nuevo" element={<FormPedidos />} />
//                    <Route path="/pedidos/:id" element={<FormPedidos />} />

//                    {/* FACTURAS Y CATEGOR�AS */}
//                    <Route path="/facturas" element={<Facturas />} />
//                    <Route path="/categorias" element={<Categorias />} />

//                    {/* HOME */}
//                    <Route path="/" element={<Categorias />} />

//                    {/* Crear nueva cotizaci�n para una orden */}
//                    <Route
//                        path="/presupuestos/nuevo/:ordenId"
//                        element={<FormPresupuestos />}
//                    />

//                    {/* Cargar cotizaciones existentes de un proveedor para esa orden */}
//                    <Route
//                        path="/presupuestos/cargar/:ordenId/:proveedorId"
//                        element={<FormPresupuestos />}
//                    />

//                    {/* Listar todas las cotizaciones de una orden */}
//                    <Route
//                        path="/cotizaciones/:ordenId"
//                        element={<ListaPresupuestos />}
//                    />




//                </Routes>
//            </div>
//        </div>
//    );
//}

// src/App.jsx
import React from 'react';
import { Routes, Route } from 'react-router-dom';

import { SideBar } from './Components/SideBar.jsx';

import { ListaProveedores } from './Pages/ListaProveedores.jsx';
import { FormProveedores } from './Pages/FormProveedores.jsx';
import { DetallesProveedores } from './Pages/DetallesProveedores.jsx';
import { Categorias } from './Pages/Categorias.jsx';

import ListaProductos from './Pages/ListaProductos.jsx';
import FormProductos from './Pages/FormProductos.jsx';
import ListaCotizaciones from './Pages/ListaCotizaciones.jsx';
import FormCotizacion from './Pages/FormCotizacion.jsx';

import ListaPedidos from './Pages/ListaPedidos.jsx';
import FormPedidos from './Pages/FormPedidos.jsx';

import { Facturas } from './Pages/Facturas.jsx';
import Stock from './Pages/Stock.jsx';

import ListaPresupuestos from './Pages/ListaPresupuestos.jsx';
import FormPresupuestos from './Pages/FormPresupuestos.jsx';

import './App.css';

export default function App() {
    return (
        <div className="flex h-screen overflow-hidden">
            <SideBar />
            <div className="flex-1 overflow-auto bg-gray-50">
                <Routes>
                    {/* PESTA�A STOCK */}
                    <Route path="/stock" element={<Stock />} />
                    {/* Como FormPedidos maneja crear (sin id) y editar (con id) */}
                    <Route path="/pedidos/nuevo" element={<FormPedidos />} />
                    <Route path="/pedidos/:id" element={<FormPedidos />} />

                    {/* PROVEEDORES */}
                    <Route path="/proveedores" element={<ListaProveedores />} />
                    <Route path="/proveedores/nuevo" element={<FormProveedores />} />
                    <Route path="/proveedores/:id/detalles" element={<DetallesProveedores />} />
                    <Route path="/proveedores/:id/editar" element={<FormProveedores />} />

                    {/* PRODUCTOS */}
                    <Route path="/productos" element={<ListaProductos />} />
                    <Route path="/productos/nuevo" element={<FormProductos />} />
                    <Route path="/productos/:id/editar" element={<FormProductos />} />
                    <Route path="/productos/:id/detalles" element={<FormProductos />} />

                    {/* PEDIDOS */}
                    <Route path="/pedidos" element={<ListaPedidos />} />

                    {/* FACTURAS Y CATEGOR�AS */}
                    <Route path="/facturas" element={<Facturas />} />
                    <Route path="/categorias" element={<Categorias />} />

                    {/* HOME */}
                    <Route path="/" element={<Categorias />} />

                    {/* Crear nueva cotizaci�n para una orden */}
                    <Route
                        path="/presupuestos/nuevo/:ordenId"
                        element={<FormPresupuestos />}
                    />

                    {/* Cargar cotizaciones existentes de un proveedor para esa orden */}
                    <Route
                        path="/presupuestos/cargar/:ordenId/:proveedorId"
                        element={<FormPresupuestos />}
                    />

                    {/* Listar todas las cotizaciones de una orden */}
                    {/* Rutas de �Cotizaciones� (Presupuestos) */}
                    <Route path="/cotizaciones" element={<ListaCotizaciones />} />
                    <Route path="/cotizaciones/:ordenId" element={<ListaCotizaciones />} />
                    <Route
                        path="/cotizaciones/:ordenId/nueva"
                        element={<FormCotizacion />}
                    />
                </Routes>
            </div>
        </div>
    );
}

