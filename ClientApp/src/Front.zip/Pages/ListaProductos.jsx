﻿//// src/Pages/ListaProductos.jsx
//import React, { useEffect, useState } from 'react';
//import DataTable from 'react-data-table-component';
//import { FaRegEdit, FaTrash, FaEye } from 'react-icons/fa';
//import { Link, useNavigate } from 'react-router-dom';
//import {
//    fetchProductos,
//    deleteProducto
//} from '../api/productos';

//export default function ListaProductos() {
//    const [data, setData] = useState([]);
//    const [filter, setFilter] = useState('');
//    const navigate = useNavigate();

//    useEffect(() => {
//        load();
//    }, []);

//    async function load() {
//        try {
//            const list = await fetchProductos();
//            setData(list);
//        } catch (e) {
//            console.error(e);
//        }
//    }

//    async function handleDelete(id) {
//        if (!window.confirm('¿Eliminar este producto?')) return;
//        try {
//            await deleteProducto(id);
//            load();
//        } catch (e) {
//            console.error(e);
//        }
//    }

//    const columns = [
//        { name: 'ID', selector: row => row.idProducto, sortable: true },
//        { name: 'Nombre', selector: row => row.nombre, sortable: true },
//        {
//            name: 'Categoría',
//            selector: row => row.categoria?.nombre || '—',
//            sortable: true
//        },
//        { name: 'Marca', selector: row => row.marca, sortable: true },
//        { name: 'Stock', selector: row => row.cantidadTotal, sortable: true },
//        {
//            name: 'Acciones',
//            cell: row => (
//                <div className="flex gap-4">
//                    <button
//                        onClick={() => navigate(`/productos/${row.idProducto}/detalles`)}
//                        title="Ver detalles"
//                        className="text-green-600 hover:text-green-800"
//                    ><FaEye /></button>
//                    <button
//                        onClick={() => navigate(`/productos/${row.idProducto}/editar`)}
//                        title="Editar"
//                        className="text-sky-600 hover:text-sky-800"
//                    ><FaRegEdit /></button>
//                    <button
//                        onClick={() => handleDelete(row.idProducto)}
//                        title="Eliminar"
//                        className="text-red-600 hover:text-red-800"
//                    ><FaTrash /></button>
//                </div>
//            ),
//            ignoreRowClick: true, allowOverflow: true, button: true
//        }
//    ];

//    const filtered = data.filter(p =>
//        p.nombre.toLowerCase().includes(filter.toLowerCase())
//    );

//    return (
//        <div className="p-6 bg-gray-100 min-h-screen">
//            <div className="flex justify-between items-center mb-4">
//                <h2 className="text-xl font-bold text-sky-600">Productos</h2>
//                <Link to="/productos/nuevo">
//                    <button className="bg-sky-500 text-white px-4 py-2 rounded hover:bg-sky-600">
//                        + Nuevo Producto
//                    </button>
//                </Link>
//            </div>

//            <div className="mb-4">
//                <input
//                    type="text"
//                    placeholder="Buscar por nombre…"
//                    value={filter}
//                    onChange={e => setFilter(e.target.value)}
//                    className="w-full border rounded p-2"
//                />
//            </div>

//            <DataTable
//                columns={columns}
//                data={filtered}
//                pagination
//                highlightOnHover
//            />
//        </div>
//    );
//}

// src/Pages/ListaProductos.jsx
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { useNavigate } from 'react-router-dom';
import {
    fetchProductos,
    deleteProducto
} from '../api/productos';

export default function ListaProductos({ lowStockOnly = false }) {
    const [data, setData] = useState([]);
    const [filter, setFilter] = useState('');
    const [seleccionados, setSeleccionados] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        load();
    }, []);

    async function load() {
        try {
            const list = await fetchProductos();
            setData(list);
        } catch (e) {
            console.error(e);
        }
    }

    async function handleDelete(id) {
        if (!window.confirm('¿Eliminar este producto?')) return;
        try {
            await deleteProducto(id);
            load();
        } catch (e) {
            console.error(e);
        }
    }

    // Filtrar por nombre
    const filtered = data.filter(p =>
        p.nombre.toLowerCase().includes(filter.toLowerCase())
    );

    // Si lowStockOnly, además filtramos p.cantidadTotal < p.cantidadMinima
    const displayed = lowStockOnly
        ? filtered.filter(p => p.cantidadTotal < p.cantidadMinima)
        : filtered;

    const columns = [
        { name: 'ID', selector: row => row.idProducto, sortable: true },
        { name: 'Nombre', selector: row => row.nombre, sortable: true },
        {
            name: 'Categoría',
            selector: row => row.categoria?.nombre || '—',
            sortable: true
        },
        { name: 'Marca', selector: row => row.marca, sortable: true },
        { name: 'Stock', selector: row => row.cantidadTotal, sortable: true },
        {
            name: 'Acciones',
            cell: row => (
                <div className="flex gap-4">
                    <button
                        onClick={() => navigate(`/productos/${row.idProducto}/detalles`)}
                        title="Ver detalles"
                        className="text-green-600 hover:text-green-800"
                    >👁️</button>
                    <button
                        onClick={() => navigate(`/productos/${row.idProducto}/editar`)}
                        title="Editar"
                        className="text-sky-600 hover:text-sky-800"
                    >✏️</button>
                    <button
                        onClick={() => handleDelete(row.idProducto)}
                        title="Eliminar"
                        className="text-red-600 hover:text-red-800"
                    >🗑️</button>
                </div>
            ),
            ignoreRowClick: true, allowOverflow: true, button: true
        }
    ];

    // Cuando el usuario marca/desmarca filas:
    const handleSelectionChange = ({ selectedRows }) => {
        // selectedRows es el arreglo de objetos "producto"
        // Mapeamos para quedarnos solo con idProducto y nombre
        setSeleccionados(
            selectedRows.map(p => ({
                idProducto: p.idProducto,
                nombre: p.nombre,
                cantidad: Math.max(1, p.cantidadMinima - p.cantidadTotal) // sugerencia: cantidad mínima a pedir
            }))
        );
    };

    // Al pulsar “Generar Pedido” en modo Poco Stock:
    const handleGenerarPedido = () => {
        if (seleccionados.length === 0) {
            alert('Debes seleccionar al menos un producto.');
            return;
        }
        // Navegamos a FormPedidos, pasándole en el estado la lista de productos preseleccionados
        navigate('/pedidos/nuevo', { state: { preselected: seleccionados } });
    };

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-sky-600">
                    {lowStockOnly ? 'Productos con poco stock' : 'Productos'}
                </h2>
                {!lowStockOnly && (
                    <button
                        onClick={() => navigate('/productos/nuevo')}
                        className="bg-sky-500 text-white px-4 py-2 rounded hover:bg-sky-600"
                    >
                        + Nuevo Producto
                    </button>
                )}
            </div>

            <div className="mb-4 flex gap-4">
                <input
                    type="text"
                    placeholder="Buscar por nombre…"
                    value={filter}
                    onChange={e => setFilter(e.target.value)}
                    className="w-full border rounded p-2"
                />
                {lowStockOnly && (
                    <button
                        onClick={handleGenerarPedido}
                        className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                    >
                        Generar Pedido
                    </button>
                )}
            </div>

            <DataTable
                columns={columns}
                data={displayed}
                pagination
                highlightOnHover
                // En modo Poco stock activamos filas seleccionables
                selectableRows={lowStockOnly}
                onSelectedRowsChange={handleSelectionChange}
            />
        </div>
    );
}
