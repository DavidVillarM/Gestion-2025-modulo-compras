// src/Pages/FormCotizacion.jsx
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { useNavigate, useParams } from 'react-router-dom';

import {
    fetchOrden,
    fetchProveedoresParaOrden
} from '../api/ordenes';

import {
    fetchPresupuestos,
    createPresupuesto,
    updatePresupuesto,
    deletePresupuesto
} from '../api/presupuestos';

export default function FormCotizacion() {
    const { ordenId } = useParams();
    const navigate = useNavigate();

    const [orden, setOrden] = useState(null);
    const [proveedores, setProveedores] = useState([]);
    const [selectedProveedor, setSelectedProveedor] = useState('');
    const [fechaEntrega, setFechaEntrega] = useState('');
    const [detalles, setDetalles] = useState([]); // { idProducto, nombre, cantidad, precio, iva5, iva10 }

    useEffect(() => {
        // 1) Cargar la orden y sus detalles:
        fetchOrden(ordenId)
            .then(o => {
                setOrden(o);
                setDetalles(
                    o.detalles.map(d => ({
                        idProducto: d.idProducto,
                        nombre: d.nombreProducto,
                        cantidad: d.cantidad,
                        precio: 0,
                        iva5: 0,
                        iva10: 0
                    }))
                );
            })
            .catch(console.error);

        // 2) Obtener lista de proveedores para esta orden:
        fetchProveedoresParaOrden(ordenId)
            .then(setProveedores)
            .catch(console.error);
    }, [ordenId]);

    const handleSave = () => {
        if (!selectedProveedor) {
            alert('Debes elegir un proveedor.');
            return;
        }
        if (detalles.some(d => d.precio <= 0)) {
            alert('Todos los productos deben tener precio positivo.');
            return;
        }
        // Calcular totales:
        let subtotal = 0, iva5 = 0, iva10 = 0;
        detalles.forEach(d => {
            subtotal += d.precio * d.cantidad;
            iva5 += d.iva5 * d.cantidad;
            iva10 += d.iva10 * d.cantidad;
        });
        const total = subtotal + iva5 + iva10;

        const dto = {
            IdProveedor: parseInt(selectedProveedor, 10),
            FechaEntrega: fechaEntrega ? new Date(fechaEntrega) : new Date(),
            Subtotal: subtotal,
            Iva5: iva5,
            Iva10: iva10,
            Total: total,
            Detalles: detalles.map(d => ({
                IdProducto: d.idProducto,
                Cantidad: d.cantidad,
                Precio: d.precio,
                Iva5: d.iva5,
                Iva10: d.iva10
            }))
        };

        // Si ya existe presupuesto de este proveedor para esta orden, podr�amos usar updatePresupuesto.
        // Para simplificar, asumimos que siempre es �nuevo�:
        createPresupuesto(ordenId, dto)
            .then(() => {
                navigate(`/cotizaciones/${ordenId}`);
            })
            .catch(err => {
                console.error(err);
                alert('Error al guardar la cotizaci�n.');
            });
    };

    if (!orden) return <div className="p-6">Cargando cotizaci�n�</div>;

    const cols = [
        { name: 'ID', selector: row => row.idProducto, sortable: true, width: '80px' },
        { name: 'Producto', selector: row => row.nombre, sortable: true },
        { name: 'Cantidad', selector: row => row.cantidad, sortable: true, width: '100px' },
        {
            name: 'Precio',
            cell: row => (
                <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={row.precio}
                    onChange={e => {
                        const val = parseFloat(e.target.value) || 0;
                        setDetalles(prev =>
                            prev.map(d =>
                                d.idProducto === row.idProducto
                                    ? { ...d, precio: val }
                                    : d
                            )
                        );
                    }}
                    className="w-24 border rounded px-1"
                />
            )
        },
        {
            name: 'IVA 5%',
            cell: row => (
                <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={row.iva5}
                    onChange={e => {
                        const val = parseFloat(e.target.value) || 0;
                        setDetalles(prev =>
                            prev.map(d =>
                                d.idProducto === row.idProducto
                                    ? { ...d, iva5: val }
                                    : d
                            )
                        );
                    }}
                    className="w-20 border rounded px-1"
                />
            )
        },
        {
            name: 'IVA 10%',
            cell: row => (
                <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={row.iva10}
                    onChange={e => {
                        const val = parseFloat(e.target.value) || 0;
                        setDetalles(prev =>
                            prev.map(d =>
                                d.idProducto === row.idProducto
                                    ? { ...d, iva10: val }
                                    : d
                            )
                        );
                    }}
                    className="w-20 border rounded px-1"
                />
            )
        }
    ];

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <h1 className="text-2xl font-bold mb-4">
                Nueva Cotizaci�n � Orden #{ordenId}
            </h1>

            <div className="flex gap-4 mb-4 items-center">
                <div className="flex flex-col">
                    <label className="text-sm">Proveedor</label>
                    <select
                        value={selectedProveedor}
                        onChange={e => setSelectedProveedor(e.target.value)}
                        className="border rounded px-2 py-1"
                    >
                        <option value="">-- Selecciona proveedor --</option>
                        {proveedores.map(p => (
                            <option key={p.idProveedor} value={p.idProveedor}>
                                {p.nombre} ({p.ruc})
                            </option>
                        ))}
                    </select>
                </div>

                <div className="flex flex-col">
                    <label className="text-sm">Fecha Entrega</label>
                    <input
                        type="date"
                        value={fechaEntrega}
                        onChange={e => setFechaEntrega(e.target.value)}
                        className="border rounded px-2 py-1"
                    />
                </div>

                <div className="ml-auto">
                    <button
                        onClick={handleSave}
                        className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
                    >
                        Guardar Cotizaci�n
                    </button>
                </div>
            </div>

            <DataTable
                title="Productos a Cotizar"
                columns={cols}
                data={detalles}
                highlightOnHover
                responsive
            />
        </div>
    );
}
