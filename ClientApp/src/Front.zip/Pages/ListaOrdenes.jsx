// src/Pages/ListaOrdenes.jsx
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { MdEdit, MdAttachMoney } from 'react-icons/md';
import { FiTrash2 } from 'react-icons/fi';
import { useNavigate } from 'react-router-dom';

import {
    fetchOrdenes,
    deleteOrden,
    fetchOrden,
    updateOrden
} from '../api/ordenes';

export default function ListaOrdenes() {
    const [ordenes, setOrdenes] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        load();
    }, []);

    const load = () => {
        fetchOrdenes()
            .then(setOrdenes)
            .catch(console.error);
    };

    // Ver o editar la orden (redirige a FormOrden)
    const handleEdit = id => {
        navigate(`/pedidos/${id}`);
    };

    // Eliminar la orden
    const handleDelete = id => {
        if (!window.confirm('�Eliminar esta solicitud?')) return;
        deleteOrden(id)
            .then(() => load())
            .catch(console.error);
    };

    // Solicitar Cotizaci�n: cambia estado a "PENDIENTE" y luego abre FormPresupuesto
    const handleSolicitarCotizacion = id => {
        // 1) Obtengo la orden actual
        fetchOrden(id)
            .then(o => {
                const payload = {
                    estado: 'PENDIENTE',
                    ordenDetalles: o.detalles.map(d => ({
                        idProducto: d.idProducto,
                        cantidad: d.cantidad
                    }))
                };
                return updateOrden(id, payload);
            })
            .then(() => {
                navigate(`/cotizaciones/${id}/nueva`);
            })
            .catch(err => {
                console.error(err);
                alert('Error al cambiar a PENDIENTE. Revisa la consola.');
            });
    };

    const columns = [
        {
            name: 'ID',
            selector: row => row.idOrden,
            sortable: true,
            width: '80px'
        },
        {
            name: 'Fecha',
            selector: row => (row.fecha ? row.fecha.split('T')[0] : ''),
            sortable: true
        },
        {
            name: 'Estado',
            selector: row => row.estado,
            sortable: true
        },
        {
            name: 'Acciones',
            cell: row => (
                <div className="flex gap-3">
                    <button
                        onClick={() => handleEdit(row.idOrden)}
                        title="Ver/Editar"
                        className="text-blue-600 hover:text-blue-800"
                    >
                        <MdEdit />
                    </button>

                    {row.estado === 'INCOMPLETA' && (
                        <button
                            onClick={() => handleSolicitarCotizacion(row.idOrden)}
                            title="Solicitar Cotizaci�n"
                            className="text-green-600 hover:text-green-800"
                        >
                            <MdAttachMoney />
                        </button>
                    )}

                    <button
                        onClick={() => handleDelete(row.idOrden)}
                        title="Eliminar"
                        className="text-red-600 hover:text-red-800"
                    >
                        <FiTrash2 />
                    </button>
                </div>
            ),
            ignoreRowClick: true,
            allowOverflow: true,
            button: true
        }
    ];

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-2xl font-bold text-sky-600">Solicitudes</h2>
                <button
                    onClick={() => navigate('/pedidos/nuevo')}
                    className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
                >
                    + Nueva Solicitud
                </button>
            </div>
            <DataTable
                columns={columns}
                data={ordenes}
                pagination
                highlightOnHover
            />
        </div>
    );
}
