// src/Pages/ListaCotizaciones.jsx
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { FaRegEdit, FaTrash, FaCalendarAlt } from 'react-icons/fa';
import { useNavigate, useParams } from 'react-router-dom';

import {
    fetchPresupuestos,
    deletePresupuesto
} from '../api/presupuestos';

export default function ListaCotizaciones() {
    const { ordenId } = useParams();
    const navigate = useNavigate();
    const [presupuestos, setPresupuestos] = useState([]);

    useEffect(() => {
        if (ordenId) load(ordenId);
    }, [ordenId]);

    const load = id => {
        fetchPresupuestos(id)
            .then(setPresupuestos)
            .catch(console.error);
    };

    const handleView = idPresu => {
        // Si quisieras una vista detallada, podr�as redirigir a /cotizaciones/{ordenId}/{idPresu}/ver
        alert(`Ver cotizaci�n #${idPresu}`);
    };

    const handleEdit = idPresu => {
        navigate(`/cotizaciones/${ordenId}/nueva?edit=${idPresu}`);
    };

    const handleDelete = idPresu => {
        if (!window.confirm('�Eliminar esta cotizaci�n?')) return;
        deletePresupuesto(ordenId, idPresu)
            .then(() => load(ordenId))
            .catch(console.error);
    };

    const columns = [
        { name: 'ID', selector: row => row.idPresupuesto, sortable: true, width: '80px' },
        { name: 'Proveedor', selector: row => row.nombreProveedor, sortable: true },
        {
            name: 'Fecha Entrega',
            selector: row => row.fechaEntrega.split('T')[0],
            sortable: true,
            width: '140px'
        },
        { name: 'Total', selector: row => row.total.toFixed(2), sortable: true, width: '110px' },
        {
            name: 'Acciones',
            cell: row => (
                <div className="flex gap-3">
                    <button
                        onClick={() => handleView(row.idPresupuesto)}
                        title="Ver"
                        className="text-blue-600 hover:text-blue-800"
                    >
                        <FaCalendarAlt />
                    </button>
                    <button
                        onClick={() => handleEdit(row.idPresupuesto)}
                        title="Editar"
                        className="text-sky-600 hover:text-sky-800"
                    >
                        <FaRegEdit />
                    </button>
                    <button
                        onClick={() => handleDelete(row.idPresupuesto)}
                        title="Eliminar"
                        className="text-red-600 hover:text-red-800"
                    >
                        <FaTrash />
                    </button>
                </div>
            ),
            ignoreRowClick: true,
            allowOverflow: true,
            button: true
        }
    ];

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <h2 className="text-2xl font-bold text-sky-600 mb-4">
                {ordenId ? `Cotizaciones de la Orden #${ordenId}` : 'Cotizaciones'}
            </h2>
            <DataTable
                columns={columns}
                data={presupuestos}
                pagination
                highlightOnHover
            />
        </div>
    );
}
