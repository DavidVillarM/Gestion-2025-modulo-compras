// src/Pages/ListaPedidosFinales.jsx
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { FaRegEye, FaTrash } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

import {
    fetchPedidos,
    deletePedido
} from '../api/pedidos';

export default function ListaPedidosFinales() {
    const [pedidos, setPedidos] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        load();
    }, []);

    const load = () => {
        fetchPedidos()
            .then(setPedidos)
            .catch(console.error);
    };

    const handleView = id => {
        navigate(`/pedidos/finales/${id}`);
    };

    const handleDelete = id => {
        if (!window.confirm('�Eliminar este pedido final?')) return;
        deletePedido(id)
            .then(() => load())
            .catch(console.error);
    };

    const columns = [
        { name: 'ID', selector: row => row.idPedido, sortable: true, width: '80px' },
        { name: 'Orden #', selector: row => row.idOrden, sortable: true, width: '100px' },
        { name: 'Proveedor', selector: row => row.nombreProveedor, sortable: true },
        { name: 'Monto Total', selector: row => row.montoTotal.toFixed(2), sortable: true, width: '120px' },
        {
            name: 'Acciones',
            cell: row => (
                <div className="flex gap-3">
                    <button
                        onClick={() => handleView(row.idPedido)}
                        title="Ver Detalle"
                        className="text-blue-600 hover:text-blue-800"
                    >
                        <FaRegEye />
                    </button>
                    <button
                        onClick={() => handleDelete(row.idPedido)}
                        title="Eliminar"
                        className="text-red-600 hover:text-red-800"
                    >
                        <FaTrash />
                    </button>
                </div>
            ),
            ignoreRowClick: true,
            allowOverflow: true,
            button: true
        }
    ];

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <h2 className="text-2xl font-bold text-sky-600 mb-4">
                Pedidos de Compra Finales
            </h2>
            <DataTable
                columns={columns}
                data={pedidos}
                pagination
                highlightOnHover
            />
        </div>
    );
}
