// src/Pages/PocoStock.jsx
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { useNavigate } from 'react-router-dom';
import { fetchProductos } from '../api/productos';

/**
 * Muestra �nicamente los productos cuyo stock (cantidadTotal) 
 * es menor que la cantidad m�nima (cantidadMinima). 
 * Permite seleccionar filas y luego pulsar �Generar Solicitud� 
 * para enviar al formulario de orden (FormPedidos) los productos preseleccionados.
 */
export default function PocoStock() {
    const [productos, setProductos] = useState([]);
    const [seleccionados, setSeleccionados] = useState([]);
    const [filtro, setFiltro] = useState('');
    const navigate = useNavigate();

    useEffect(() => {
        // 1) Cargar todos los productos y luego filtraremos en el cliente
        fetchProductos()
            .then(list => {
                // Filtrar aquellos cuyo stock < cantidad m�nima
                const bajos = list.filter(p => p.cantidadTotal < p.cantidadMinima);
                setProductos(bajos);
            })
            .catch(console.error);
    }, []);

    // 2) Columnas de la grilla �Poco stock�
    const columns = [
        { name: 'ID', selector: row => row.idProducto, sortable: true, width: '80px' },
        { name: 'Nombre', selector: row => row.nombre, sortable: true },
        {
            name: 'Categor�a',
            selector: row => row.categoria?.nombre || '�',
            sortable: true
        },
        { name: 'Marca', selector: row => row.marca, sortable: true },
        {
            name: 'Stock Actual',
            selector: row => row.cantidadTotal,
            sortable: true,
            width: '120px'
        },
        {
            name: 'Stock M�nimo',
            selector: row => row.cantidadMinima,
            sortable: true,
            width: '120px'
        },
        {
            name: 'Sugerido',
            selector: row => row.cantidadMinima - row.cantidadTotal,
            sortable: false,
            width: '100px',
            cell: row => <span>{row.cantidadMinima - row.cantidadTotal}</span>
        }
    ];

    // 3) Productos filtrados por nombre en funci�n de input
    const filtrados = productos.filter(p =>
        p.nombre.toLowerCase().includes(filtro.toLowerCase())
    );

    // 4) Al hacer clic en �Generar Solicitud� enviamos al formulario FormPedidos
    //    la lista de productos preseleccionados, con la cantidad sugerida = (cantidadMinima - cantidadTotal)
    const handleGenerarSolicitud = () => {
        if (seleccionados.length === 0) {
            alert('Debes seleccionar al menos un producto para generar la solicitud.');
            return;
        }

        // Construir array con { idProducto, nombre, cantidad }
        const preselected = seleccionados.map(p => ({
            idProducto: p.idProducto,
            nombre: p.nombre,
            cantidad: p.cantidadMinima - p.cantidadTotal
        }));

        // Navegar al formulario de orden, pasando los preseleccionados en location.state
        navigate('/pedidos/nuevo', { state: { preselected } });
    };

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-sky-600">Productos con Poco Stock</h2>
                <button
                    onClick={handleGenerarSolicitud}
                    className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                    Generar Solicitud
                </button>
            </div>

            <div className="mb-4">
                <input
                    type="text"
                    placeholder="Buscar por nombre�"
                    value={filtro}
                    onChange={e => setFiltro(e.target.value)}
                    className="w-full border rounded p-2"
                />
            </div>

            <DataTable
                columns={columns}
                data={filtrados}
                selectableRows
                highlightOnHover
                pagination
                onSelectedRowsChange={({ selectedRows }) =>
                    setSeleccionados(selectedRows)
                }
            />
        </div>
    );
}
