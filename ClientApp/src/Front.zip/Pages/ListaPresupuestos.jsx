﻿//// src/Pages/ListaPresupuestos.jsx
//import React, { useEffect, useState } from 'react'
//import { useParams, useNavigate } from 'react-router-dom'
//import DataTable from 'react-data-table-component'

//export default function ListaPresupuestos() {
//    const { ordenId } = useParams()
//    const navigate = useNavigate()

//    const [cotizaciones, setCotizaciones] = useState([])
//    const [loading, setLoading] = useState(true)
//    const [error, setError] = useState('')

//    useEffect(() => {
//        if (!ordenId) {
//            setError('Falta el ID de la orden.')
//            setLoading(false)
//            return
//        }
//        fetch(`/api/ordenes/${ordenId}/presupuestos`)
//            .then(res => {
//                if (!res.ok) throw new Error(res.statusText)
//                return res.json()
//            })
//            .then(data => setCotizaciones(data))
//            .catch(err => {
//                console.error(err)
//                setError('No se pudieron cargar las cotizaciones.')
//            })
//            .finally(() => setLoading(false))
//    }, [ordenId])

//    if (loading) return <p>Cargando cotizaciones…</p>
//    if (error) return <p className="text-red-600">{error}</p>

//    const columns = [
//        { name: 'ID', selector: r => r.id, sortable: true },
//        { name: 'Proveedor', selector: r => r.proveedor.nombre, sortable: true },
//        { name: 'Fecha Entrega', selector: r => r.fechaEntrega?.split('T')[0], sortable: true },
//        {
//            name: 'Total',
//            selector: r =>
//                r.detalles
//                    .reduce((sum, d) => sum + d.precio * d.cantidad, 0)
//                    .toFixed(2),
//            right: true
//        },
//        {
//            name: 'Acciones',
//            cell: row => (
//                <button
//                    onClick={() => navigate(`/presupuestos/${ordenId}/detalle/${row.id}`)}
//                >
//                    Ver
//                </button>
//            ),
//            ignoreRowClick: true,
//            button: true
//        }
//    ]

//    return (
//        <div className="p-6">
//            <h2 className="text-2xl font-bold mb-4">
//                Cotizaciones del Pedido #{ordenId}
//            </h2>
//            <DataTable
//                columns={columns}
//                data={cotizaciones}
//                pagination
//                highlightOnHover
//            />
//        </div>
//    )
//}
// src/Pages/ListaPresupuestos.jsx
import React, { useState, useEffect } from 'react';
import DataTable from 'react-data-table-component';
import { FaRegEdit, FaTrash, FaFileInvoice } from 'react-icons/fa';
import { useNavigate, useParams } from 'react-router-dom';

export default function ListaPresupuestos() {
    const { ordenId } = useParams();
    const [presupuestos, setPresupuestos] = useState([]);
    const navigate = useNavigate();

    useEffect(() => {
        fetch(`/api/presupuestos?ordenId=${ordenId}`)
            .then(res => res.json())
            .then(setPresupuestos)
            .catch(console.error);
    }, [ordenId]);

    const handleView = id => {
        // Por ejemplo, navegar a “ver detalle de cotización”
        navigate(`/presupuestos/${id}/ver`);
    };
    const handleEdit = id => {
        // Para editar/cargar la cotización de un proveedor en esta orden:
        // Asumimos que la API utiliza “idProveedor” como parte de la ruta
        // Para simplificar, supongamos que row.idProveedor está disponible
        navigate(`/presupuestos/cargar/${ordenId}/${id}`);
    };
    const handleDelete = id => {
        if (!window.confirm('¿Eliminar esta cotización?')) return;
        fetch(`/api/presupuestos/${id}`, { method: 'DELETE' })
            .then(res => {
                if (!res.ok) throw new Error('Error eliminando');
                setPresupuestos(prev => prev.filter(p => p.idPresupuesto !== id));
            })
            .catch(console.error);
    };

    const columns = [
        { name: 'ID', selector: row => row.idPresupuesto, sortable: true },
        { name: 'Proveedor', selector: row => row.nombreProveedor, sortable: true },
        { name: 'Fecha Entrega', selector: row => row.fechaEntrega?.split('T')[0], sortable: true },
        { name: 'Total', selector: row => row.total.toFixed(2), sortable: true },
        {
            name: 'Acciones',
            cell: row => (
                <div className="flex gap-2">
                    <button onClick={() => handleView(row.idPresupuesto)} title="Ver">
                        <FaFileInvoice className="text-blue-600 hover:text-blue-800" />
                    </button>
                    <button onClick={() => handleEdit(row.idProveedor)} title="Cargar/Editar">
                        <FaRegEdit className="text-sky-600 hover:text-sky-800" />
                    </button>
                    <button onClick={() => handleDelete(row.idPresupuesto)} title="Eliminar">
                        <FaTrash className="text-red-600 hover:text-red-800" />
                    </button>
                </div>
            ),
            ignoreRowClick: true,
            allowOverflow: true,
            button: true
        }
    ];

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <h2 className="text-2xl font-bold text-sky-600 mb-4">
                Cotizaciones de la Orden #{ordenId}
            </h2>
            <DataTable
                columns={columns}
                data={presupuestos}
                pagination
                highlightOnHover
            />
        </div>
    );
}
