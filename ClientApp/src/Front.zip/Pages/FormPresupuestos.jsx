﻿//// src/Pages/FormPresupuestos.jsx
//import React, { useState, useEffect } from 'react'
//import { useParams, useNavigate } from 'react-router-dom'

//export default function FormPresupuestos() {
//    const { ordenId } = useParams()
//    const navigate = useNavigate()

//    const [orden, setOrden] = useState(null)
//    const [fechaEntrega, setFechaEntrega] = useState('')
//    const [detalles, setDetalles] = useState([])
//    const [error, setError] = useState('')

//    useEffect(() => {
//        if (!ordenId) return

//        fetch(`/api/ordenes/${ordenId}`)
//            .then(res => {
//                if (!res.ok) throw new Error(`HTTP ${res.status}`)
//                return res.json()
//            })
//            .then(data => {
//                setOrden(data)
//                setFechaEntrega(data.fechaEntrega?.split('T')[0] || '')
//                setDetalles(
//                    data.ordenDetalles.map(d => ({
//                        idDetalle: d.idDetalle,
//                        idProducto: d.idProducto,
//                        cantidad: d.cantidad,
//                        producto: d.producto,
//                        precio: '',
//                        iva5: '',
//                        iva10: ''
//                    }))
//                )
//            })
//            .catch(err => {
//                console.error(err)
//                setError('No se pudo cargar la orden.')
//            })
//    }, [ordenId])

//    const handleChangeDetalle = (idx, field, value) => {
//        setDetalles(prev => {
//            const copy = [...prev]
//            copy[idx] = { ...copy[idx], [field]: value }
//            return copy
//        })
//    }

//    const handleSubmit = e => {
//        e.preventDefault()

//        const payload = {
//            ordenId: Number(ordenId),
//            fechaEntrega,
//            detalles: detalles.map(d => ({
//                idProducto: d.idProducto,
//                precio: parseFloat(d.precio),
//                iva5: parseFloat(d.iva5) || 0,
//                iva10: parseFloat(d.iva10) || 0
//            }))
//        }

//        fetch('/api/presupuestos', {
//            method: 'POST',
//            headers: { 'Content-Type': 'application/json' },
//            body: JSON.stringify(payload)
//        })
//            .then(res => {
//                if (!res.ok) throw new Error('Error al guardar')
//                 navigate(`/cotizaciones/${ordenId}`)
//            })
//            .catch(err => {
//                console.error(err)
//                setError('Error al guardar el presupuesto.')
//            })
//    }

//    if (error) return <p className="text-red-600">{error}</p>
//    if (!orden) return <p>Cargando datos de la orden…</p>

//    return (
//        <div className="p-6 bg-gray-50 min-h-screen">
//            <h2 className="text-2xl font-bold text-sky-600 mb-6">
//                Crear Cotización para Pedido #{ordenId}
//            </h2>
//            <form onSubmit={handleSubmit} className="space-y-4">
//                <div>
//                    <label className="block font-medium">Fecha de Entrega</label>
//                    <input
//                        type="date"
//                        value={fechaEntrega}
//                        onChange={e => setFechaEntrega(e.target.value)}
//                        required
//                        className="border rounded p-2 mt-1"
//                    />
//                </div>
//                <table className="w-full table-auto border-collapse">
//                    <thead>
//                        <tr>
//                            <th className="border p-2">Producto</th>
//                            <th className="border p-2">Cantidad</th>
//                            <th className="border p-2">Precio</th>
//                            <th className="border p-2">IVA 5%</th>
//                            <th className="border p-2">IVA 10%</th>
//                        </tr>
//                    </thead>
//                    <tbody>
//                        {detalles.map((d, i) => (
//                            <tr key={d.idDetalle}>
//                                <td className="border p-2">{d.producto.nombre}</td>
//                                <td className="border p-2">{d.cantidad}</td>
//                                <td className="border p-2">
//                                    <input
//                                        type="number"
//                                        step="0.01"
//                                        value={d.precio}
//                                        onChange={e => handleChangeDetalle(i, 'precio', e.target.value)}
//                                        className="w-full border rounded p-1"
//                                        required
//                                    />
//                                </td>
//                                <td className="border p-2">
//                                    <input
//                                        type="number"
//                                        step="0.01"
//                                        value={d.iva5}
//                                        onChange={e => handleChangeDetalle(i, 'iva5', e.target.value)}
//                                        className="w-full border rounded p-1"
//                                    />
//                                </td>
//                                <td className="border p-2">
//                                    <input
//                                        type="number"
//                                        step="0.01"
//                                        value={d.iva10}
//                                        onChange={e => handleChangeDetalle(i, 'iva10', e.target.value)}
//                                        className="w-full border rounded p-1"
//                                    />
//                                </td>
//                            </tr>
//                        ))}
//                    </tbody>
//                </table>
//                <div className="text-right">
//                    <button
//                        type="submit"
//                        className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
//                    >
//                        Guardar Presupuesto
//                    </button>
//                </div>
//            </form>
//        </div>
//    )
//}

// src/Pages/FormPresupuestos.jsx
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, useLocation } from 'react-router-dom';
import DataTable from 'react-data-table-component';

export default function FormPresupuestos() {
    const { ordenId, proveedorId } = useParams();
    const navigate = useNavigate();
    const location = useLocation();

    const [orden, setOrden] = useState(null);
    const [proveedores, setProveedores] = useState([]);
    const [selectedProveedor, setSelectedProveedor] = useState(proveedorId || '');
    const [fechaEntrega, setFechaEntrega] = useState('');
    const [detalles, setDetalles] = useState([]); // { idProducto, nombre, cantidad, precio, iva5, iva10 }

    // Columnas para mostrar los productos de la orden
    const columns = [
        { name: 'ID', selector: row => row.idProducto, sortable: true },
        { name: 'Producto', selector: row => row.nombre, sortable: true },
        { name: 'Cantidad', selector: row => row.cantidad, sortable: true },
        {
            name: 'Precio',
            cell: row => (
                <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={row.precio || ''}
                    onChange={e => {
                        const val = parseFloat(e.target.value) || 0;
                        setDetalles(ds =>
                            ds.map(d =>
                                d.idProducto === row.idProducto
                                    ? { ...d, precio: val }
                                    : d
                            )
                        );
                    }}
                    className="w-20 border rounded px-1"
                />
            )
        },
        {
            name: 'IVA 5%',
            cell: row => (
                <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={row.iva5 || ''}
                    onChange={e => {
                        const val = parseFloat(e.target.value) || 0;
                        setDetalles(ds =>
                            ds.map(d =>
                                d.idProducto === row.idProducto
                                    ? { ...d, iva5: val }
                                    : d
                            )
                        );
                    }}
                    className="w-16 border rounded px-1"
                />
            )
        },
        {
            name: 'IVA 10%',
            cell: row => (
                <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={row.iva10 || ''}
                    onChange={e => {
                        const val = parseFloat(e.target.value) || 0;
                        setDetalles(ds =>
                            ds.map(d =>
                                d.idProducto === row.idProducto
                                    ? { ...d, iva10: val }
                                    : d
                            )
                        );
                    }}
                    className="w-16 border rounded px-1"
                />
            )
        }
    ];

    // Cargo la orden y la lista de proveedores (filtrados por categorías)
    useEffect(() => {
        // 1) Obtengo la orden completa (con detalles y cada producto y su categoría)
        fetch(`/api/ordenes/${ordenId}`)
            .then(res => res.json())
            .then(o => {
                setOrden(o);
                // Construyo la tabla de detalles:
                setDetalles(
                    o.detalles.map(d => ({
                        idProducto: d.idProducto,
                        nombre: d.nombreProducto,
                        cantidad: d.cantidad,
                        precio: 0,
                        iva5: 0,
                        iva10: 0
                    }))
                );
                // Calculo un “set” de categorías para pedir proveedores
                const categoriasSet = new Set(o.detalles.map(d => d.categoriaNombre));
                // Paso 2) Obtener proveedores que vendan al menos una de esas categorías
                // Por ejemplo: GET /api/proveedores?categorias=1,2
                // (Ajusta el endpoint en tu backend para que acepte un array de IDs de categorías)
                const categoriaIds = o.detalles.map(d => d.idCategoria);
                fetch(`/api/proveedores?categorias=${[...new Set(categoriaIds)].join(',')}`)
                    .then(res => res.json())
                    .then(setProveedores)
                    .catch(console.error)
            })
            .catch(console.error);
    }, [ordenId]);

    // Guardar la cotización
    const handleSave = () => {
        if (!selectedProveedor) {
            alert('Selecciona un proveedor');
            return;
        }
        // Calculamos totales
        let subtotal = 0, iva5 = 0, iva10 = 0;
        detalles.forEach(d => {
            subtotal += d.precio * d.cantidad;
            iva5 += d.iva5 * d.cantidad;
            iva10 += d.iva10 * d.cantidad;
        });
        const total = subtotal + iva5 + iva10;

        const payload = {
            idOrden: parseInt(ordenId, 10),
            idProveedor: parseInt(selectedProveedor, 10),
            fechaEntrega,
            subtotal,
            iva5,
            iva10,
            total,
            detalles: detalles.map(d => ({
                idProducto: d.idProducto,
                cantidad: d.cantidad,
                precio: d.precio,
                iva5: d.iva5,
                iva10: d.iva10
            }))
        };

        fetch('/api/presupuestos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        })
            .then(res => {
                if (!res.ok) throw new Error('Error guardando cotización');
                navigate(`/cotizaciones/${ordenId}`);
            })
            .catch(console.error);
    };

    if (!orden) return <div className="p-6">Cargando...</div>;

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <h1 className="text-2xl font-bold mb-4">
                {proveedorId ? 'Cargar Cotización' : 'Nueva Cotización'} - Orden #{ordenId}
            </h1>

            <div className="mb-4 flex gap-4">
                <div className="flex flex-col">
                    <label className="text-sm">Proveedor</label>
                    <select
                        value={selectedProveedor}
                        onChange={e => setSelectedProveedor(e.target.value)}
                        className="border rounded px-2 py-1"
                    >
                        <option value="">-- Selecciona proveedor --</option>
                        {proveedores.map(p => (
                            <option key={p.idProveedor} value={p.idProveedor}>
                                {p.nombre} ({p.ruc})
                            </option>
                        ))}
                    </select>
                </div>
                <div className="flex flex-col">
                    <label className="text-sm">Fecha Entrega</label>
                    <input
                        type="date"
                        value={fechaEntrega}
                        onChange={e => setFechaEntrega(e.target.value)}
                        className="border rounded px-2 py-1"
                    />
                </div>
            </div>

            <DataTable
                title="Productos de la Orden"
                columns={columns}
                data={detalles}
                highlightOnHover
                responsive
            />

            <div className="text-right mt-4">
                <button
                    onClick={handleSave}
                    className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
                >
                    {proveedorId ? 'Actualizar Cotización' : 'Guardar Cotización'}
                </button>
            </div>
        </div>
    );
}
