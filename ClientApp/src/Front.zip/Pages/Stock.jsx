﻿//// src/Pages/Stock.jsx
//import React, { useState } from 'react'
//import ListaProductos from './ListaProductos.jsx'
//import ListaPedidos from './ListaPedidos.jsx'

//export default function Stock() {
//    const [tab, setTab] = useState('general')

//    return (
//        <div className="p-6 bg-gray-100 min-h-screen">
//            {/* Cabecera de pestañas */}
//            <div className="flex justify-start space-x-4 border-b mb-6 bg-white p-2">
//                <button
//                    onClick={() => setTab('general')}
//                    className={`px-4 py-2 font-medium ${tab === 'general'
//                        ? 'border-b-2 border-blue-600 text-blue-600'
//                        : 'text-gray-600 hover:text-blue-600'
//                        }`}
//                >
//                    Productos
//                </button>
//                <button
//                    onClick={() => setTab('pedidos')}
//                    className={`px-4 py-2 font-medium ${tab === 'pedidos'
//                        ? 'border-b-2 border-blue-600 text-blue-600'
//                        : 'text-gray-600 hover:text-blue-600'
//                        }`}
//                >
//                    Pedidos
//                </button>
//                <button
//                    onClick={() => setTab('poco')}
//                    className={`px-4 py-2 font-medium ${tab === 'poco'
//                        ? 'border-b-2 border-blue-600 text-blue-600'
//                        : 'text-gray-600 hover:text-blue-600'
//                        }`}
//                >
//                    Poco stock
//                </button>
//            </div>

//            {/* Contenido de cada pestaña */}
//            {tab === 'general' && <ListaProductos />}
//            {tab === 'pedidos' && <ListaPedidos />}
//            {tab === 'poco' && <ListaProductos lowStockOnly={true} />}
//        </div>
//    )
//}

// src/Pages/Stock.jsx
import React, { useState } from 'react';
import ListaProductos from './ListaProductos.jsx';
import ListaPedidos from './ListaPedidos.jsx';
import PocoStock from './PocoStock.jsx';  // <–– Importamos el nuevo componente

export default function Stock() {
    const [tab, setTab] = useState('general');

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            {/* Cabecera de pestañas */}
            <div className="flex justify-start space-x-4 border-b mb-6 bg-white p-2">
                <button
                    onClick={() => setTab('general')}
                    className={`px-4 py-2 font-medium ${tab === 'general'
                            ? 'border-b-2 border-blue-600 text-blue-600'
                            : 'text-gray-600 hover:text-blue-600'
                        }`}
                >
                    Productos
                </button>
                <button
                    onClick={() => setTab('pedidos')}
                    className={`px-4 py-2 font-medium ${tab === 'pedidos'
                            ? 'border-b-2 border-blue-600 text-blue-600'
                            : 'text-gray-600 hover:text-blue-600'
                        }`}
                >
                    Pedidos
                </button>
                <button
                    onClick={() => setTab('poco')}
                    className={`px-4 py-2 font-medium ${tab === 'poco'
                            ? 'border-b-2 border-blue-600 text-blue-600'
                            : 'text-gray-600 hover:text-blue-600'
                        }`}
                >
                    Poco stock
                </button>
            </div>

            {/* Contenido de cada pestaña */}
            {tab === 'general' && <ListaProductos />}
            {tab === 'pedidos' && <ListaPedidos />}
            {tab === 'poco' && <PocoStock />}
        </div>
    );
}
