﻿// src/Pages/FormOrden.jsx
import React, { useEffect, useState } from 'react';
import DataTable from 'react-data-table-component';
import { useNavigate, useParams, useLocation } from 'react-router-dom';

import {
    fetchOrden,
    createOrden,
    updateOrden
} from '../api/ordenes';

export default function FormOrden() {
    const { id } = useParams();            // Si existe, estoy editando; si no, creando
    const location = useLocation();
    const navigate = useNavigate();

    const [productos, setProductos] = useState([]);       // lista de todos los productos
    const [seleccionados, setSeleccionados] = useState([]); // { idProducto, nombre, cantidad }
    const [filtrarNombre, setFiltrarNombre] = useState('');
    const [estado, setEstado] = useState('INCOMPLETA');   // solo se usa en edición

    useEffect(() => {
        // 1) Cargar todos los productos para que el usuario los seleccione
        fetch('/api/productos')
            .then(res => res.json())
            .then(setProductos)
            .catch(console.error);

        if (id) {
            // 2) Si estamos editando, traer la orden actual
            fetchOrden(id)
                .then(o => {
                    setEstado(o.estado);
                    setSeleccionados(
                        o.detalles.map(d => ({
                            idProducto: d.idProducto,
                            nombre: d.nombreProducto,
                            cantidad: d.cantidad
                        }))
                    );
                })
                .catch(console.error);
        } else {
            // 3) Si venimos de “Poco stock”, podremos recibir location.state.preselected
            const pre = location.state?.preselected || [];
            if (pre.length > 0) {
                setSeleccionados(pre);
            }
        }
    }, [id, location.state]);

    // Filtrar productos por nombre
    const filtrados = productos.filter(p =>
        p.nombre.toLowerCase().includes(filtrarNombre.toLowerCase())
    );

    // Columnas de “Todos los productos”
    const colsProductos = [
        { name: 'ID', selector: row => row.idProducto, sortable: true, width: '80px' },
        { name: 'Producto', selector: row => row.nombre, sortable: true },
        { name: 'Marca', selector: row => row.marca, sortable: true },
        { name: 'Stock', selector: row => row.cantidadTotal, sortable: true }
    ];

    // Columnas de “Productos seleccionados”
    const colsSeleccionados = [
        { name: 'ID', selector: row => row.idProducto, sortable: true, width: '80px' },
        { name: 'Producto', selector: row => row.nombre, sortable: true },
        {
            name: 'Cantidad',
            cell: row => (
                <input
                    type="number"
                    min="1"
                    value={row.cantidad}
                    onChange={e => {
                        const qty = Math.max(1, parseInt(e.target.value, 10) || 1);
                        setSeleccionados(prev =>
                            prev.map(p =>
                                p.idProducto === row.idProducto
                                    ? { ...p, cantidad: qty }
                                    : p
                            )
                        );
                    }}
                    className="bg-gray-200 rounded-sm w-16 text-center px-1"
                />
            )
        }
    ];

    // Guardar (crear o actualizar la orden)
    const handleSave = () => {
        if (!seleccionados.length) {
            alert('Debes seleccionar al menos un producto.');
            return;
        }

        const dto = {
            Estado: estado, // en creación el back ignorará este valor y lo pondrá en INCOMPLETA
            OrdenDetalles: seleccionados.map(p => ({
                IdProducto: p.idProducto,
                Cantidad: p.cantidad
            }))
        };

        if (!id) {
            // Crear nueva orden
            createOrden(dto)
                .then(() => {
                    navigate('/pedidos');
                })
                .catch(err => {
                    console.error(err);
                    alert('Error al crear la orden.');
                });
        } else {
            // Actualizar orden existente
            updateOrden(id, dto)
                .then(() => {
                    navigate('/pedidos');
                })
                .catch(err => {
                    console.error(err);
                    alert('Error al actualizar la orden.');
                });
        }
    };

    return (
        <div className="p-6 bg-gray-100 min-h-screen">
            <h1 className="text-2xl font-bold mb-4">
                {id ? 'Editar' : 'Nueva'} Solicitud de Compra
            </h1>

            <div className="flex gap-4 mb-4 items-center">
                <div className="flex flex-col">
                    <label className="text-sm">Filtrar producto</label>
                    <input
                        type="text"
                        placeholder="Buscar por nombre…"
                        value={filtrarNombre}
                        onChange={e => setFiltrarNombre(e.target.value)}
                        className="border rounded px-2 py-1"
                    />
                </div>

                {id && (
                    <div className="flex flex-col">
                        <label className="text-sm">Estado</label>
                        <select
                            value={estado}
                            onChange={e => setEstado(e.target.value)}
                            className="border rounded px-2 py-1"
                        >
                            <option value="INCOMPLETA">INCOMPLETA</option>
                            <option value="PENDIENTE">PENDIENTE</option>
                            <option value="COMPLETA">COMPLETA</option>
                        </select>
                    </div>
                )}

                <div className="ml-auto">
                    <button
                        onClick={handleSave}
                        className="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700"
                    >
                        {id ? 'Actualizar Solicitud' : 'Crear Solicitud'}
                    </button>
                </div>
            </div>

            <DataTable
                title="Todos los Productos"
                columns={colsProductos}
                data={filtrados}
                selectableRows
                onSelectedRowsChange={({ selectedRows }) => {
                    setSeleccionados(
                        selectedRows.map(p => ({
                            idProducto: p.idProducto,
                            nombre: p.nombre,
                            cantidad: Math.max(1, p.cantidadMinima - p.cantidadTotal)
                        }))
                    );
                }}
                pagination
                highlightOnHover
            />

            <div className="mt-6">
                <h2 className="text-xl font-semibold mb-2">
                    Productos Seleccionados
                </h2>
                <DataTable
                    columns={colsSeleccionados}
                    data={seleccionados}
                    highlightOnHover
                    noHeader
                />
            </div>
        </div>
    );
}
