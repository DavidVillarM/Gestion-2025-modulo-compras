﻿// DTOs/ProveedorSimpleDto.cs
namespace ModuloCompras.DTOs
{
    public class ProveedorSimpleDto
    {
        public int IdProveedor { get; set; }
        public string Nombre { get; set; }
        public string Ruc { get; set; }
    }
}
