﻿// DTOs/ProductoCreateDto.cs
using System.Text.Json.Serialization;

namespace ModuloCompras.DTOs
{
    public class ProductoCreateDto
    {
        [JsonPropertyName("nombre")]
        public string Nombre { get; set; }

        [JsonPropertyName("marca")]
        public string Marca { get; set; }

        [JsonPropertyName("idCategoria")]
        public int? IdCategoria { get; set; }

        [JsonPropertyName("cantidadTotal")]
        public int CantidadTotal { get; set; }

        [JsonPropertyName("cantidadMinima")]
        public int CantidadMinima { get; set; }
    }
}