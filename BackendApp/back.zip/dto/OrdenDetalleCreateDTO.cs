﻿// dto/OrdenDetalleCreateDTO.cs
namespace ModuloCompras.Dto
{
    public class OrdenDetalleCreateDTO
    {
        // IdProducto y Cantidad para cada línea de orden
        public int IdProducto { get; set; }
        public int Cantidad { get; set; }
    }
}