﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace ModuloCompras.DTOs
{
    public class ProveedorCreateDto
    {
        [Required] public string Ruc { get; set; }
        [Required] public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public string NombreContacto { get; set; }

        // IDs de categorías a asignar
        public List<int> CategoriaIds { get; set; } = new();
    }
}
