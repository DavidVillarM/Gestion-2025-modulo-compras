﻿namespace ModuloCompras.DTOs
{
    public class CategoriaAsignadaDto
    {
        public int IdCategoria { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string Estado { get; set; }
    }
}
