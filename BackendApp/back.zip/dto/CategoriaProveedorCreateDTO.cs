﻿namespace ModuloCompras.DTOs
{
    public class CategoriaProveedorCreateDto
    {
        public int IdProveedor { get; set; }
        public int IdCategoria { get; set; }
        public string Estado { get; set; }
    }
}
