﻿using System.Collections.Generic;

namespace ModuloCompras.DTOs
{
    public class ProveedorReadDto
    {
        public int IdProveedor { get; set; }
        public string Ruc { get; set; }
        public string Nombre { get; set; }
        public string Telefono { get; set; }
        public string Correo { get; set; }
        public string NombreContacto { get; set; }

        public List<CategoriaAsignadaDto> Categorias { get; set; }
    }
}
