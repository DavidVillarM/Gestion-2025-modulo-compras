﻿// DTOs/OrdenManualCreateDto.cs
namespace ModuloCompras.DTOs
{
    public class OrdenManualCreateDto
    {
        public string Estado { get; set; }            // p.ej. "GENERADA"
        public List<OrdenManualItemDto> Items { get; set; }
    }

    public class OrdenManualItemDto
    {
        public int IdProducto { get; set; }
        public int IdProveedor { get; set; }
        public decimal PrecioUnitario { get; set; }
        public int Cantidad { get; set; }
        public decimal Iva { get; set; }
    }
}
