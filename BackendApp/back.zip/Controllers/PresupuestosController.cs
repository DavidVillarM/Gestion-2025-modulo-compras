﻿// Controllers/PresupuestosController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuloCompras.Data;
using ModuloCompras.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ModuloCompras.Controllers
{
    [ApiController]
    // Ruta anidada: cada presupuesto siempre pertenece a una orden específica
    [Route("api/ordenes/{ordenId}/[controller]")]
    public class PresupuestosController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public PresupuestosController(ApplicationDbContext db) => _db = db;

        // ─────────── 1) GET /api/ordenes/{ordenId}/presupuestos ───────────
        // Lista todas las cotizaciones (presupuestos) creadas para esta orden.
        [HttpGet]
        public async Task<IActionResult> GetAll(int ordenId)
        {
            var ordenExiste = await _db.Ordenes.AnyAsync(o => o.IdOrden == ordenId);
            if (!ordenExiste) return NotFound($"La orden {ordenId} no existe.");

            var presupuestos = await _db.Presupuestos
                .Where(p => p.IdOrden == ordenId)
                .Include(p => p.Proveedor)
                .Include(p => p.Detalles)
                    .ThenInclude(d => d.Producto)
                .ToListAsync();

            var result = presupuestos.Select(p => new
            {
                p.IdPresupuesto,
                p.IdProveedor,
                NombreProveedor = p.Proveedor.Nombre,
                p.FechaEntrega,
                p.Subtotal,
                p.Iva5,
                p.Iva10,
                p.Total,
                Detalles = p.Detalles.Select(d => new
                {
                    d.IdPresupuestoDetalle,
                    d.IdProducto,
                    d.Cantidad,
                    d.Precio,
                    d.Iva5,
                    d.Iva10,
                    NombreProducto = d.Producto.Nombre
                }).ToList()
            });

            return Ok(result);
        }

        // ─────────── 2) POST /api/ordenes/{ordenId}/presupuestos ───────────
        // Crea una cotización para esta orden (dto lleva IdProveedor, FechaEntrega y lista de detalles).
        [HttpPost]
        public async Task<IActionResult> Create(int ordenId, [FromBody] PresupuestoCreateDto dto)
        {
            // Verificar que la orden exista:
            var orden = await _db.Ordenes.FindAsync(ordenId);
            if (orden == null) return NotFound($"La orden {ordenId} no existe.");

            // Verificar que el proveedor exista:
            var prov = await _db.Proveedores.FindAsync(dto.IdProveedor);
            if (prov == null) return NotFound($"El proveedor {dto.IdProveedor} no existe.");

            // Crear encabezado de Presupuesto
            var presu = new Presupuesto
            {
                IdOrden = ordenId,
                IdProveedor = dto.IdProveedor,
                FechaEntrega = dto.FechaEntrega,
                Subtotal = dto.Subtotal,
                Iva5 = dto.Iva5,
                Iva10 = dto.Iva10,
                Total = dto.Total
            };

            // Agregar detalles
            foreach (var d in dto.Detalles)
            {
                var prodExiste = await _db.Productos.AnyAsync(p => p.IdProducto == d.IdProducto);
                if (!prodExiste)
                    return BadRequest($"Producto {d.IdProducto} no encontrado.");

                presu.Detalles.Add(new PresupuestoDetalle
                {
                    IdProducto = d.IdProducto,
                    Cantidad = d.Cantidad,
                    Precio = d.Precio,
                    Iva5 = d.Iva5,
                    Iva10 = d.Iva10
                });
            }

            _db.Presupuestos.Add(presu);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(GetAll),
                                   new { ordenId = ordenId },
                                   new { presu.IdPresupuesto });
        }

        // ─────────── 3) PUT /api/ordenes/{ordenId}/presupuestos/{idPresu} ───────────
        // Actualiza una cotización completa (encabezado + detalles).
        [HttpPut("{idPresu}")]
        public async Task<IActionResult> Update(int ordenId, int idPresu, [FromBody] PresupuestoCreateDto dto)
        {
            var presu = await _db.Presupuestos
                .Include(p => p.Detalles)
                .FirstOrDefaultAsync(p => p.IdPresupuesto == idPresu && p.IdOrden == ordenId);

            if (presu == null)
                return NotFound($"El presupuesto {idPresu} para la orden {ordenId} no existe.");

            presu.IdProveedor = dto.IdProveedor;
            presu.FechaEntrega = dto.FechaEntrega;
            presu.Subtotal = dto.Subtotal;
            presu.Iva5 = dto.Iva5;
            presu.Iva10 = dto.Iva10;
            presu.Total = dto.Total;

            // Reemplazar detalles
            _db.PresupuestoDetalles.RemoveRange(presu.Detalles);
            presu.Detalles.Clear();

            foreach (var d in dto.Detalles)
            {
                presu.Detalles.Add(new PresupuestoDetalle
                {
                    IdProducto = d.IdProducto,
                    Cantidad = d.Cantidad,
                    Precio = d.Precio,
                    Iva5 = d.Iva5,
                    Iva10 = d.Iva10
                });
            }

            await _db.SaveChangesAsync();
            return NoContent();
        }

        // ─────────── 4) DELETE /api/ordenes/{ordenId}/presupuestos/{idPresu} ───────────
        // Elimina una cotización (presupuesto) y sus detalles.
        [HttpDelete("{idPresu}")]
        public async Task<IActionResult> Delete(int ordenId, int idPresu)
        {
            var presu = await _db.Presupuestos.FindAsync(idPresu);
            if (presu == null || presu.IdOrden != ordenId)
                return NotFound($"El presupuesto {idPresu} para la orden {ordenId} no existe.");

            _db.Presupuestos.Remove(presu);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }

    // ─────────── DTO para crear/actualizar Presupuesto ───────────
    public class PresupuestoCreateDto
    {
        public int IdProveedor { get; set; }
        public DateTime FechaEntrega { get; set; }
        public decimal Subtotal { get; set; }
        public decimal Iva5 { get; set; }
        public decimal Iva10 { get; set; }
        public decimal Total { get; set; }
        public List<PresupuestoDetalleCreateDto> Detalles { get; set; } = new();
    }

    public class PresupuestoDetalleCreateDto
    {
        public int IdProducto { get; set; }
        public int Cantidad { get; set; }
        public decimal Precio { get; set; }
        public decimal Iva5 { get; set; }
        public decimal Iva10 { get; set; }
    }
}
