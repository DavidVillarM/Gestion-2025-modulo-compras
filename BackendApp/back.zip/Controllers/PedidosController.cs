﻿//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using ModuloCompras.Data;
//using ModuloCompras.DTOs;
//using ModuloCompras.Models;
//using System.Linq;
//using System.Threading.Tasks;
//using System.Collections.Generic;
//using System;

//namespace ModuloCompras.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class PedidosController : ControllerBase
//    {
//        private readonly ApplicationDbContext _db;
//        public PedidosController(ApplicationDbContext db) => _db = db;

//        // GET: api/pedidos
//        [HttpGet]
//        public async Task<IActionResult> GetAll()
//        {
//            var list = await _db.Pedidos
//                                .Include(p => p.Proveedor)
//                                .Select(p => new PedidoReadDTO
//                                {
//                                    IdPedido = p.IdPedido,
//                                    IdOrden = p.IdOrden,
//                                    MontoTotal = p.MontoTotal,
//                                    FechaPedido = p.FechaPedido ?? DateTime.MinValue,
//                                    FechaEntrega = p.FechaEntrega ?? DateTime.MinValue,
//                                    Estado = p.Estado,
//                                    Detalles = new List<PedidoDetalleReadDTO>()
//                                })
//                                .ToListAsync();

//            return Ok(list);
//        }

//        // GET: api/pedidos/{id}
//        [HttpGet("{id}")]
//        public async Task<IActionResult> GetById(int id)
//        {
//            var entidad = await _db.Pedidos
//                                  .Include(p => p.Proveedor)
//                                  .Include(p => p.Detalles)
//                                    .ThenInclude(d => d.Producto)
//                                  .FirstOrDefaultAsync(p => p.IdPedido == id);

//            if (entidad == null)
//                return NotFound();

//            var dto = new PedidoReadDTO
//            {
//                IdPedido = entidad.IdPedido,
//                IdOrden = entidad.IdOrden,
//                MontoTotal = entidad.MontoTotal,
//                FechaPedido = entidad.FechaPedido ?? DateTime.MinValue,
//                FechaEntrega = entidad.FechaEntrega ?? DateTime.MinValue,
//                Estado = entidad.Estado,
//                Detalles = entidad.Detalles
//                             .Select(d => new PedidoDetalleReadDTO
//                             {
//                                 IdPedidoDetalle = d.IdPedidoDetalle,
//                                 IdProducto = d.IdProducto,
//                                 Cotizacion = d.Cotizacion,
//                                 Cantidad = d.Cantidad,
//                                 Iva = d.Iva,
//                                 NombreProducto = d.Producto != null ? d.Producto.Nombre : null,
//                                 NombreProveedor = entidad.Proveedor != null ? entidad.Proveedor.Nombre : null
//                             })
//                             .ToList()
//            };

//            return Ok(dto);
//        }

//        // POST: api/pedidos
//        [HttpPost]
//        public async Task<IActionResult> Create([FromBody] PedidoCreateDTO dto)
//        {
//            var entidad = new Pedido
//            {
//                IdOrden = dto.IdOrden,
//                MontoTotal = dto.MontoTotal,
//                FechaPedido = dto.FechaPedido,
//                FechaEntrega = dto.FechaEntrega,
//                Estado = dto.Estado,
//                IdProveedor = dto.IdProveedor  // El front debe enviarlo en CreateDTO
//            };

//            foreach (var det in dto.Detalles)
//            {
//                entidad.Detalles.Add(new PedidoDetalle
//                {
//                    IdProducto = det.IdProducto,
//                    Cotizacion = det.Cotizacion,
//                    Cantidad = det.Cantidad,
//                    Iva = det.Iva
//                });
//            }

//            _db.Pedidos.Add(entidad);
//            await _db.SaveChangesAsync();

//            var createdDto = new PedidoReadDTO
//            {
//                IdPedido = entidad.IdPedido,
//                IdOrden = entidad.IdOrden,
//                MontoTotal = entidad.MontoTotal,
//                FechaPedido = entidad.FechaPedido ?? DateTime.MinValue,
//                FechaEntrega = entidad.FechaEntrega ?? DateTime.MinValue,
//                Estado = entidad.Estado,
//                Detalles = entidad.Detalles
//                             .Select(d => new PedidoDetalleReadDTO
//                             {
//                                 IdPedidoDetalle = d.IdPedidoDetalle,
//                                 IdProducto = d.IdProducto,
//                                 Cotizacion = d.Cotizacion,
//                                 Cantidad = d.Cantidad,
//                                 Iva = d.Iva,
//                                 NombreProducto = null,
//                                 NombreProveedor = null
//                             })
//                             .ToList()
//            };

//            return CreatedAtAction(nameof(GetById),
//                                   new { id = createdDto.IdPedido },
//                                   createdDto);
//        }

//        // POST: api/pedidos/{idOrden}/generar-auto
//        [HttpPost("{idOrden}/generar-auto")]
//        public async Task<IActionResult> GenerarAutomático(int idOrden)
//        {
//            var presupuestos = await _db.PresupuestoDetalles
//                                        .Where(d => d.Presupuesto.IdOrden == idOrden)
//                                        .Include(d => d.Presupuesto)
//                                        .ToListAsync();

//            if (!presupuestos.Any())
//                return BadRequest($"No hay presupuestos para la orden {idOrden}.");

//            // Elegir el precio más bajo por producto
//            var mejores = presupuestos
//                          .GroupBy(d => d.IdProducto)
//                          .Select(g => g.OrderBy(x => x.Precio).First())
//                          .ToList();

//            var entidad = new Pedido
//            {
//                IdOrden = idOrden,
//                IdProveedor = 0, // Se ignora aquí: cada línea proviene de distintos presupuestos
//                MontoTotal = 0m,
//                FechaPedido = DateTime.UtcNow,
//                FechaEntrega = DateTime.UtcNow.AddDays(7),
//                Estado = "GENERADA"
//            };

//            foreach (var m in mejores)
//            {
//                entidad.Detalles.Add(new PedidoDetalle
//                {
//                    IdProducto = m.IdProducto,
//                    Cotizacion = m.Precio,
//                    Cantidad = m.Cantidad,
//                    Iva = m.Iva5 + m.Iva10
//                });

//                entidad.MontoTotal += (m.Precio * m.Cantidad) + (m.Iva5 + m.Iva10);
//            }

//            _db.Pedidos.Add(entidad);
//            await _db.SaveChangesAsync();

//            var dto = new PedidoReadDTO
//            {
//                IdPedido = entidad.IdPedido,
//                IdOrden = entidad.IdOrden,
//                MontoTotal = entidad.MontoTotal,
//                FechaPedido = entidad.FechaPedido.Value,
//                FechaEntrega = entidad.FechaEntrega.Value,
//                Estado = entidad.Estado,
//                Detalles = entidad.Detalles
//                             .Select(d => new PedidoDetalleReadDTO
//                             {
//                                 IdPedidoDetalle = d.IdPedidoDetalle,
//                                 IdProducto = d.IdProducto,
//                                 Cotizacion = d.Cotizacion,
//                                 Cantidad = d.Cantidad,
//                                 Iva = d.Iva,
//                                 NombreProducto = null,
//                                 NombreProveedor = null
//                             })
//                             .ToList()
//            };

//            return CreatedAtAction(nameof(GetById),
//                                   new { id = dto.IdPedido },
//                                   dto);
//        }

//        // PUT: api/pedidos/{id}
//        [HttpPut("{id}")]
//        public async Task<IActionResult> Update(int id, [FromBody] PedidoCreateDTO dto)
//        {
//            var entidad = await _db.Pedidos
//                                  .Include(p => p.Detalles)
//                                  .FirstOrDefaultAsync(p => p.IdPedido == id);

//            if (entidad == null)
//                return NotFound();

//            entidad.IdOrden = dto.IdOrden;
//            entidad.IdProveedor = dto.IdProveedor;
//            entidad.MontoTotal = dto.MontoTotal;
//            entidad.FechaPedido = dto.FechaPedido;
//            entidad.FechaEntrega = dto.FechaEntrega;
//            entidad.Estado = dto.Estado;

//            _db.PedidoDetalles.RemoveRange(entidad.Detalles);
//            entidad.Detalles.Clear();

//            foreach (var det in dto.Detalles)
//            {
//                entidad.Detalles.Add(new PedidoDetalle
//                {
//                    IdProducto = det.IdProducto,
//                    Cotizacion = det.Cotizacion,
//                    Cantidad = det.Cantidad,
//                    Iva = det.Iva
//                });
//            }

//            await _db.SaveChangesAsync();
//            return NoContent();
//        }

//        // DELETE: api/pedidos/{id}
//        [HttpDelete("{id}")]
//        public async Task<IActionResult> Delete(int id)
//        {
//            var entidad = await _db.Pedidos.FindAsync(id);
//            if (entidad == null)
//                return NotFound();

//            _db.Pedidos.Remove(entidad);
//            await _db.SaveChangesAsync();
//            return NoContent();
//        }
//    }
//}
// Controllers/PedidosController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuloCompras.Data;
using ModuloCompras.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ModuloCompras.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class PedidosController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public PedidosController(ApplicationDbContext db) => _db = db;

        // ─────────── 1) GET /api/pedidos ───────────
        // Devuelve todos los pedidos finales (ódenes de compra) generados.
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var pedidos = await _db.Pedidos
                .Include(p => p.Proveedor)
                .Include(p => p.Detalles)
                    .ThenInclude(d => d.Producto)
                .ToListAsync();

            var result = pedidos.Select(p => new
            {
                p.IdPedido,
                p.IdOrden,
                p.IdProveedor,
                NombreProveedor = p.Proveedor.Nombre,
                p.MontoTotal,
                FechaPedido = p.FechaPedido,
                FechaEntrega = p.FechaEntrega,
                p.Estado,
                Detalles = p.Detalles.Select(d => new
                {
                    d.IdPedidoDetalle,
                    d.IdProducto,
                    d.Cantidad,
                    d.Cotizacion,
                    d.Iva,
                    NombreProducto = d.Producto.Nombre
                }).ToList()
            });

            return Ok(result);
        }

        // ─────────── 2) GET /api/pedidos/{id} ───────────
        // Devuelve un pedido final específico.
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var pedido = await _db.Pedidos
                .Include(p => p.Proveedor)
                .Include(p => p.Detalles)
                    .ThenInclude(d => d.Producto)
                .FirstOrDefaultAsync(p => p.IdPedido == id);

            if (pedido == null) return NotFound($"El pedido {id} no existe.");

            var dto = new
            {
                pedido.IdPedido,
                pedido.IdOrden,
                pedido.IdProveedor,
                NombreProveedor = pedido.Proveedor.Nombre,
                pedido.MontoTotal,
                pedido.FechaPedido,
                pedido.FechaEntrega,
                pedido.Estado,
                Detalles = pedido.Detalles.Select(d => new
                {
                    d.IdPedidoDetalle,
                    d.IdProducto,
                    d.Cantidad,
                    d.Cotizacion,
                    d.Iva,
                    NombreProducto = d.Producto.Nombre
                }).ToList()
            };

            return Ok(dto);
        }

        // ─────────── 3) POST /api/pedidos ───────────
        // (Opcional) Crear un pedido final manualmente (no suele usarse en el flujo automático).
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] PedidoCreateDto dto)
        {
            // Verificamos existencia de Orden y Proveedor
            var orden = await _db.Ordenes.FindAsync(dto.IdOrden);
            if (orden == null) return NotFound($"La orden {dto.IdOrden} no existe.");

            var prov = await _db.Proveedores.FindAsync(dto.IdProveedor);
            if (prov == null) return NotFound($"El proveedor {dto.IdProveedor} no existe.");

            var pedido = new Pedido
            {
                IdOrden = dto.IdOrden,
                IdProveedor = dto.IdProveedor,
                MontoTotal = dto.MontoTotal,
                FechaPedido = dto.FechaPedido,
                FechaEntrega = dto.FechaEntrega,
                Estado = dto.Estado
            };

            foreach (var d in dto.Detalles)
            {
                var prodExiste = await _db.Productos.AnyAsync(p => p.IdProducto == d.IdProducto);
                if (!prodExiste) return BadRequest($"El producto {d.IdProducto} no existe.");

                pedido.Detalles.Add(new PedidoDetalle
                {
                    IdProducto = d.IdProducto,
                    Cantidad = d.Cantidad,
                    Cotizacion = d.Cotizacion,
                    Iva = d.Iva
                });
            }

            _db.Pedidos.Add(pedido);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(Get), new { id = pedido.IdPedido }, new { pedido.IdPedido });
        }

        // ─────────── 4) DELETE /api/pedidos/{id} ───────────
        // Elimina un pedido final junto con sus detalles.
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var pedido = await _db.Pedidos.FindAsync(id);
            if (pedido == null) return NotFound($"El pedido {id} no existe.");

            _db.Pedidos.Remove(pedido);
            await _db.SaveChangesAsync();
            return NoContent();
        }

        // ─────────── 5) POST /api/pedidos/{idOrden}/generar-auto ───────────
        // Genera automáticamente, para la orden {idOrden}, uno o varios pedidos finales
        // agrupados por proveedor, eligiendo siempre la cotización con menor precio por producto.
        [HttpPost("{idOrden}/generar-auto")]
        public async Task<IActionResult> GenerarAuto(int idOrden)
        {
            // 1) Verificar que la orden exista:
            var orden = await _db.Ordenes.FindAsync(idOrden);
            if (orden == null) return NotFound($"La orden {idOrden} no existe.");

            // 2) Leer todos los detalles de todas las cotizaciones (PresupuestoDetalle)
            //    que pertenezcan a presupuestos de esta orden:
            var todosDetalles = await _db.PresupuestoDetalles
                .Where(d => d.Presupuesto.IdOrden == idOrden)
                .Include(d => d.Presupuesto)
                .ToListAsync();

            if (!todosDetalles.Any())
                return BadRequest("No hay cotizaciones cargadas para esta orden.");

            // 3) Agrupar por IdProducto y quedarnos con el detalle (de todosDetalles) cuyo Precio sea mínimo:
            var mejoresPorProducto = todosDetalles
                .GroupBy(d => d.IdProducto)
                .Select(g => g.OrderBy(x => x.Precio).First())
                .ToList();

            // 4) Agrupar los “mejores” por IdProveedor:
            var agrupados = mejoresPorProducto
                .GroupBy(d => d.Presupuesto.IdProveedor)
                .ToList();

            // 5) Por cada grupo (proveedor), crear un Pedido con sus detalles:
            var pedidosCreados = new List<object>();
            foreach (var grupo in agrupados)
            {
                var proveedorId = grupo.Key;
                var pedido = new Pedido
                {
                    IdOrden = idOrden,
                    IdProveedor = proveedorId,
                    MontoTotal = 0m,
                    FechaPedido = DateTime.UtcNow,
                    FechaEntrega = DateTime.UtcNow.AddDays(7), // puede ajustarse
                    Estado = "GENERADA"
                };

                foreach (var detalleMejor in grupo)
                {
                    var cantidad = detalleMejor.Cantidad;
                    var precio = detalleMejor.Precio;
                    var ivaTotal = detalleMejor.Iva5 + detalleMejor.Iva10;

                    pedido.Detalles.Add(new PedidoDetalle
                    {
                        IdProducto = detalleMejor.IdProducto,
                        Cantidad = cantidad,
                        Cotizacion = precio,
                        Iva = ivaTotal
                    });

                    // Acumular en MontoTotal:
                    pedido.MontoTotal += (precio * cantidad) + ivaTotal;
                }

                _db.Pedidos.Add(pedido);
                await _db.SaveChangesAsync();

                pedidosCreados.Add(new
                {
                    pedido.IdPedido,
                    pedido.IdProveedor,
                    pedido.MontoTotal,
                    pedido.FechaPedido,
                    pedido.FechaEntrega,
                    pedido.Estado
                });
            }

            return Ok(pedidosCreados);
        }
    }

    // ─────────── DTO para crear Pedido manual (usualmente no se usa en el flujo auto) ───────────
    public class PedidoCreateDto
    {
        public int IdOrden { get; set; }
        public int IdProveedor { get; set; }
        public decimal MontoTotal { get; set; }
        public DateTime FechaPedido { get; set; }
        public DateTime FechaEntrega { get; set; }
        public string Estado { get; set; }
        public List<PedidoDetalleCreateDto> Detalles { get; set; } = new();
    }

    public class PedidoDetalleCreateDto
    {
        public int IdProducto { get; set; }
        public int Cantidad { get; set; }
        public decimal Cotizacion { get; set; }
        public decimal Iva { get; set; }
    }
}
