﻿using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuloCompras.Data;
using ModuloCompras.Models;

namespace ModuloCompras.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductoProveedorController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public ProductoProveedorController(ApplicationDbContext db) => _db = db;

        // GET: api/productoproveedor
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductoProveedor>>> GetAll()
        {
            var list = await _db.ProductoProveedor
                .Include(pp => pp.Producto)
                .Include(pp => pp.Proveedor)
                .ToListAsync();
            return Ok(list);
        }

        // POST: api/productoproveedor
        [HttpPost]
        public async Task<ActionResult<ProductoProveedor>> Create([FromBody] ProductoProveedor dto)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var validProd = await _db.Productos.AnyAsync(p => p.IdProducto == dto.IdProducto);
            var validProv = await _db.Proveedores.AnyAsync(p => p.IdProveedor == dto.IdProveedor);
            if (!validProd || !validProv)
                return BadRequest("Producto o Proveedor inválido.");

            _db.ProductoProveedor.Add(dto);
            await _db.SaveChangesAsync();
            return CreatedAtAction(nameof(GetAll),
                                   new { id = dto.IdProductoProveedor },
                                   dto);
        }

        // DELETE: api/productoproveedor/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var ent = await _db.ProductoProveedor.FindAsync(id);
            if (ent == null) return NotFound();
            _db.ProductoProveedor.Remove(ent);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
