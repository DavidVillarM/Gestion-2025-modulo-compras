﻿using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuloCompras.Data;
using ModuloCompras.DTOs;
using ModuloCompras.Models;

namespace ModuloCompras.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductosController : ControllerBase
    {
        private readonly ApplicationDbContext _context;
        public ProductosController(ApplicationDbContext context) => _context = context;

        // GET: api/productos
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Producto>>> GetAll()
        {
            var products = await _context.Productos
                .Include(p => p.Categoria)
                .ToListAsync();
            return Ok(products);
        }

        // GET: api/productos/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<Producto>> Get(int id)
        {
            var product = await _context.Productos
                .Include(p => p.Categoria)
                .FirstOrDefaultAsync(p => p.IdProducto == id);
            if (product == null) return NotFound();
            return Ok(product);
        }

        // POST: api/productos
        [HttpPost]
        public async Task<ActionResult<Producto>> Create([FromBody] ProductoCreateDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            // Asegúrate de que dto.IdCategoria tenga valor
            if (!dto.IdCategoria.HasValue)
                return BadRequest("IdCategoria es requerido.");

            var product = new Producto
            {
                Nombre = dto.Nombre,
                Marca = dto.Marca,
                IdCategoria = dto.IdCategoria.Value,
                CantidadTotal = dto.CantidadTotal,
                CantidadMinima = dto.CantidadMinima
            };

            _context.Productos.Add(product);
            await _context.SaveChangesAsync();

            // Cargamos la navegación
            await _context.Entry(product)
                .Reference(p => p.Categoria)
                .LoadAsync();

            return CreatedAtAction(nameof(Get),
                                   new { id = product.IdProducto },
                                   product);
        }

        // PUT: api/productos/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] ProductoCreateDto dto)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var product = await _context.Productos.FindAsync(id);
            if (product == null) return NotFound();

            if (!dto.IdCategoria.HasValue)
                return BadRequest("IdCategoria es requerido.");

            product.Nombre = dto.Nombre;
            product.Marca = dto.Marca;
            product.IdCategoria = dto.IdCategoria.Value;
            product.CantidadTotal = dto.CantidadTotal;
            product.CantidadMinima = dto.CantidadMinima;

            await _context.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/productos/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var product = await _context.Productos.FindAsync(id);
            if (product == null) return NotFound();

            _context.Productos.Remove(product);
            await _context.SaveChangesAsync();
            return NoContent();
        }

        // GET: api/productos/{id}/proveedores
        [HttpGet("{id}/proveedores")]
        public async Task<ActionResult<IEnumerable<ProductoProveedor>>> GetProveedores(int id)
        {
            if (!await _context.Productos.AnyAsync(p => p.IdProducto == id))
                return NotFound();

            var list = await _context.ProductoProveedor
                .Where(pp => pp.IdProducto == id)
                .Include(pp => pp.Proveedor)
                .ToListAsync();
            return Ok(list);
        }
    }
}
