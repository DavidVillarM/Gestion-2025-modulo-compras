﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuloCompras.Data;
using ModuloCompras.DTOs;
using ModuloCompras.Models;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace ModuloCompras.Controllers
{
    [ApiController]
    [Route("api/presupuestos/{presupuestoId}/detalles")]
    public class PresupuestoDetallesController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public PresupuestoDetallesController(ApplicationDbContext db) => _db = db;

        // GET: api/presupuestos/{presupuestoId}/detalles
        [HttpGet]
        public async Task<IActionResult> GetAll(int presupuestoId)
        {
            var existePresu = await _db.Presupuestos.AnyAsync(p => p.IdPresupuesto == presupuestoId);
            if (!existePresu)
                return NotFound($"No existe el presupuesto {presupuestoId}.");

            var detalles = await _db.PresupuestoDetalles
                                   .Where(d => d.IdPresupuesto == presupuestoId)
                                   .Include(d => d.Producto)
                                   .ToListAsync();

            var result = detalles.Select(d => new PresupuestoDetalleReadDTO
            {
                IdPresupuestoDetalle = d.IdPresupuestoDetalle,
                IdProducto = d.IdProducto,
                Cantidad = d.Cantidad,
                Precio = d.Precio,
                Iva5 = d.Iva5,
                Iva10 = d.Iva10,
                NombreProducto = d.Producto != null ? d.Producto.Nombre : null
            }).ToList();

            return Ok(result);
        }

        // GET: api/presupuestos/{presupuestoId}/detalles/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int presupuestoId, int id)
        {
            var detalle = await _db.PresupuestoDetalles
                                   .Include(d => d.Producto)
                                   .FirstOrDefaultAsync(d => d.IdPresupuestoDetalle == id
                                                           && d.IdPresupuesto == presupuestoId);
            if (detalle == null)
                return NotFound($"Detalle {id} no existe para el presupuesto {presupuestoId}.");

            var dto = new PresupuestoDetalleReadDTO
            {
                IdPresupuestoDetalle = detalle.IdPresupuestoDetalle,
                IdProducto = detalle.IdProducto,
                Cantidad = detalle.Cantidad,
                Precio = detalle.Precio,
                Iva5 = detalle.Iva5,
                Iva10 = detalle.Iva10,
                NombreProducto = detalle.Producto != null ? detalle.Producto.Nombre : null
            };
            return Ok(dto);
        }

        // POST: api/presupuestos/{presupuestoId}/detalles
        [HttpPost]
        public async Task<IActionResult> Create(int presupuestoId, [FromBody] PresupuestoDetalleCreateDTO dto)
        {
            var presu = await _db.Presupuestos.FindAsync(presupuestoId);
            if (presu == null)
                return NotFound($"No existe el presupuesto {presupuestoId}.");

            var entidad = new PresupuestoDetalle
            {
                IdPresupuesto = presupuestoId,
                IdProducto = dto.IdProducto,
                Cantidad = dto.Cantidad,
                Precio = dto.Precio,
                Iva5 = dto.Iva5,
                Iva10 = dto.Iva10
            };

            _db.PresupuestoDetalles.Add(entidad);
            await _db.SaveChangesAsync();

            var readDto = new PresupuestoDetalleReadDTO
            {
                IdPresupuestoDetalle = entidad.IdPresupuestoDetalle,
                IdProducto = entidad.IdProducto,
                Cantidad = entidad.Cantidad,
                Precio = entidad.Precio,
                Iva5 = entidad.Iva5,
                Iva10 = entidad.Iva10,
                NombreProducto = null
            };

            return CreatedAtAction(
                nameof(GetById),
                new { presupuestoId = presupuestoId, id = entidad.IdPresupuestoDetalle },
                readDto);
        }

        // PUT: api/presupuestos/{presupuestoId}/detalles/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int presupuestoId, int id, [FromBody] PresupuestoDetalleCreateDTO dto)
        {
            var presu = await _db.Presupuestos.FindAsync(presupuestoId);
            if (presu == null)
                return NotFound($"No existe el presupuesto {presupuestoId}.");

            var entidad = await _db.PresupuestoDetalles
                                  .FirstOrDefaultAsync(d => d.IdPresupuestoDetalle == id
                                                         && d.IdPresupuesto == presupuestoId);
            if (entidad == null)
                return NotFound($"No existe la línea {id} para el presupuesto {presupuestoId}.");

            entidad.IdProducto = dto.IdProducto;
            entidad.Cantidad = dto.Cantidad;
            entidad.Precio = dto.Precio;
            entidad.Iva5 = dto.Iva5;
            entidad.Iva10 = dto.Iva10;

            await _db.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/presupuestos/{presupuestoId}/detalles/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int presupuestoId, int id)
        {
            var entidad = await _db.PresupuestoDetalles
                                  .FirstOrDefaultAsync(d => d.IdPresupuestoDetalle == id
                                                         && d.IdPresupuesto == presupuestoId);
            if (entidad == null)
                return NotFound($"No existe la línea {id} para el presupuesto {presupuestoId}.");

            _db.PresupuestoDetalles.Remove(entidad);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
