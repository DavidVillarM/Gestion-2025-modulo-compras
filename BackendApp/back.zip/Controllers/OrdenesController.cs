﻿//using Microsoft.AspNetCore.Mvc;
//using Microsoft.EntityFrameworkCore;
//using ModuloCompras.Data;
//using ModuloCompras.DTOs;
//using ModuloCompras.Models;
//using System.Linq;
//using System.Threading.Tasks;
//using System.Collections.Generic;

//namespace ModuloCompras.Controllers
//{
//    [ApiController]
//    [Route("api/[controller]")]
//    public class OrdenesController : ControllerBase
//    {
//        private readonly ApplicationDbContext _db;
//        public OrdenesController(ApplicationDbContext db) => _db = db;

//        // GET: api/ordenes
//        [HttpGet]
//        public async Task<IActionResult> GetAll()
//        {
//            // Incluimos Fecha en el listado principal
//            var list = await _db.Ordenes
//                                .Select(o => new OrdenReadDTO
//                                {
//                                    IdOrden = o.IdOrden,
//                                    Fecha = o.Fecha,
//                                    Estado = o.Estado,
//                                    Detalles = new List<OrdenDetalleReadDTO>()
//                                })
//                                .ToListAsync();

//            return Ok(list);
//        }

//        // GET: api/ordenes/{id}
//        [HttpGet("{id}")]
//        public async Task<IActionResult> GetById(int id)
//        {
//            var entidad = await _db.Ordenes
//                                  .Include(o => o.OrdenDetalles)
//                                    .ThenInclude(d => d.Producto)
//                                  .FirstOrDefaultAsync(o => o.IdOrden == id);

//            if (entidad == null)
//                return NotFound();

//            var dto = new OrdenReadDTO
//            {
//                IdOrden = entidad.IdOrden,
//                Fecha = entidad.Fecha,
//                Estado = entidad.Estado,
//                Detalles = entidad.OrdenDetalles
//                             .Select(d => new OrdenDetalleReadDTO
//                             {
//                                 IdOrdenDetalle = d.IdOrdenDetalle,
//                                 IdProducto = d.IdProducto,
//                                 Cantidad = d.Cantidad,
//                                 NombreProducto = d.Producto != null
//                                     ? d.Producto.Nombre
//                                     : null
//                             })
//                             .ToList()
//            };

//            return Ok(dto);
//        }

//        // POST: api/ordenes
//        [HttpPost]
//        public async Task<IActionResult> Create([FromBody] OrdenCreateDTO dto)
//        {
//            var entidad = new Orden
//            {
//                Fecha = dto.Fecha,
//                Estado = dto.Estado
//            };

//            foreach (var det in dto.OrdenDetalles)
//            {
//                entidad.OrdenDetalles.Add(new OrdenDetalle
//                {
//                    IdProducto = det.IdProducto,
//                    Cantidad = det.Cantidad
//                });
//            }

//            _db.Ordenes.Add(entidad);
//            await _db.SaveChangesAsync();

//            var createdDto = new OrdenReadDTO
//            {
//                IdOrden = entidad.IdOrden,
//                Fecha = entidad.Fecha,
//                Estado = entidad.Estado,
//                Detalles = entidad.OrdenDetalles
//                             .Select(d => new OrdenDetalleReadDTO
//                             {
//                                 IdOrdenDetalle = d.IdOrdenDetalle,
//                                 IdProducto = d.IdProducto,
//                                 Cantidad = d.Cantidad,
//                                 NombreProducto = null
//                             })
//                             .ToList()
//            };

//            return CreatedAtAction(nameof(GetById),
//                                   new { id = createdDto.IdOrden },
//                                   createdDto);
//        }

//        // PUT: api/ordenes/{id}
//        [HttpPut("{id}")]
//        public async Task<IActionResult> Update(int id, [FromBody] OrdenCreateDTO dto)
//        {
//            var entidad = await _db.Ordenes
//                                  .Include(o => o.OrdenDetalles)
//                                  .FirstOrDefaultAsync(o => o.IdOrden == id);

//            if (entidad == null)
//                return NotFound();

//            entidad.Fecha = dto.Fecha;
//            entidad.Estado = dto.Estado;

//            // Reemplazar detalles
//            _db.OrdenDetalles.RemoveRange(entidad.OrdenDetalles);
//            entidad.OrdenDetalles.Clear();

//            foreach (var det in dto.OrdenDetalles)
//            {
//                entidad.OrdenDetalles.Add(new OrdenDetalle
//                {
//                    IdProducto = det.IdProducto,
//                    Cantidad = det.Cantidad
//                });
//            }

//            await _db.SaveChangesAsync();
//            return NoContent();
//        }

//        // DELETE: api/ordenes/{id}
//        [HttpDelete("{id}")]
//        public async Task<IActionResult> Delete(int id)
//        {
//            var entidad = await _db.Ordenes.FindAsync(id);
//            if (entidad == null)
//                return NotFound();

//            _db.Ordenes.Remove(entidad);
//            await _db.SaveChangesAsync();
//            return NoContent();
//        }
//    }
//}
// Controllers/OrdenesController.cs
// Controllers/OrdenesController.cs
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuloCompras.Data;
using ModuloCompras.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ModuloCompras.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrdenesController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public OrdenesController(ApplicationDbContext db) => _db = db;

        // ─────────── 1) GET /api/ordenes ───────────
        // Devuelve la lista de todas las órdenes (solicitudes), con sus detalles anidados.
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var query = await _db.Ordenes
                .Include(o => o.OrdenDetalles)
                    .ThenInclude(d => d.Producto)
                .ToListAsync();

            var result = query.Select(o => new
            {
                IdOrden = o.IdOrden,
                Fecha = o.Fecha,    // Fecha del servidor (UTC)
                Estado = o.Estado,
                Detalles = o.OrdenDetalles.Select(d => new
                {
                    d.IdOrdenDetalle,
                    d.IdProducto,
                    d.Cantidad,
                    NombreProducto = d.Producto.Nombre,
                    CategoriaNombre = d.Producto.Categoria.Nombre
                }).ToList()
            });

            return Ok(result);
        }

        // ─────────── 2) GET /api/ordenes/{id} ───────────
        // Devuelve una orden concreta, con sus detalles y cada producto.
        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var orden = await _db.Ordenes
                .Include(o => o.OrdenDetalles)
                    .ThenInclude(d => d.Producto)
                        .ThenInclude(p => p.Categoria)
                .FirstOrDefaultAsync(o => o.IdOrden == id);

            if (orden == null) return NotFound($"La orden {id} no existe.");

            var dto = new
            {
                IdOrden = orden.IdOrden,
                Fecha = orden.Fecha,
                Estado = orden.Estado,
                Detalles = orden.OrdenDetalles.Select(d => new
                {
                    d.IdOrdenDetalle,
                    d.IdProducto,
                    d.Cantidad,
                    NombreProducto = d.Producto.Nombre,
                    IdCategoria = d.Producto.IdCategoria,
                    CategoriaNombre = d.Producto.Categoria.Nombre
                }).ToList()
            };

            return Ok(dto);
        }

        // ─────────── 3) POST /api/ordenes ───────────
        // Crea una nueva orden (solicitud). Siempre se pone Estado="INCOMPLETA" y Fecha=UTC ahora.
        [HttpPost]
        public async Task<IActionResult> Create([FromBody] OrdenCreateDto dto)
        {
            if (dto == null || dto.OrdenDetalles == null || !dto.OrdenDetalles.Any())
                return BadRequest("Debe incluir al menos un detalle de orden.");

            var orden = new Orden
            {
                Estado = "INCOMPLETA",
                Fecha = DateTime.UtcNow
            };

            foreach (var det in dto.OrdenDetalles)
            {
                // Verificar que el producto exista (opcionales: validar stock aquí)
                var existeProd = await _db.Productos.AnyAsync(p => p.IdProducto == det.IdProducto);
                if (!existeProd)
                    return BadRequest($"Producto {det.IdProducto} no encontrado.");

                orden.OrdenDetalles.Add(new OrdenDetalle
                {
                    IdProducto = det.IdProducto,
                    Cantidad = det.Cantidad
                });
            }

            _db.Ordenes.Add(orden);
            await _db.SaveChangesAsync();

            return CreatedAtAction(nameof(Get), new { id = orden.IdOrden }, new
            {
                orden.IdOrden,
                orden.Fecha,
                orden.Estado
            });
        }

        // ─────────── 4) PUT /api/ordenes/{id} ───────────
        // Actualiza el Estado y/o los Detalles de la orden. Ejemplo: cambiar de "INCOMPLETA" a "PENDIENTE"
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] OrdenCreateDto dto)
        {
            var orden = await _db.Ordenes
                .Include(o => o.OrdenDetalles)
                .FirstOrDefaultAsync(o => o.IdOrden == id);

            if (orden == null) return NotFound($"La orden {id} no existe.");

            // Actualizamos solo el Estado (no cambiamos Fecha) y reemplazamos los detalles:
            orden.Estado = dto.Estado;

            // Eliminamos todos los detalles anteriores:
            _db.OrdenDetalles.RemoveRange(orden.OrdenDetalles);
            orden.OrdenDetalles.Clear();

            foreach (var det in dto.OrdenDetalles)
            {
                var existeProd = await _db.Productos.AnyAsync(p => p.IdProducto == det.IdProducto);
                if (!existeProd)
                    return BadRequest($"Producto {det.IdProducto} no encontrado.");

                orden.OrdenDetalles.Add(new OrdenDetalle
                {
                    IdProducto = det.IdProducto,
                    Cantidad = det.Cantidad
                });
            }

            await _db.SaveChangesAsync();
            return NoContent();
        }

        // ─────────── 5) DELETE /api/ordenes/{id} ───────────
        // Elimina una orden junto con todos sus detalles (cascade).
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var orden = await _db.Ordenes.FindAsync(id);
            if (orden == null) return NotFound($"La orden {id} no existe.");

            _db.Ordenes.Remove(orden);
            await _db.SaveChangesAsync();
            return NoContent();
        }


        // ─────────── 6) GET /api/ordenes/{id}/proveedores ───────────
        // Devuelve la lista de proveedores que pueden cotizar esta orden,
        // es decir, aquellos que tienen asociada al menos una de las categorías
        // de los productos incluidos en la orden.
        [HttpGet("{id}/proveedores")]
        public async Task<IActionResult> GetProveedoresParaOrden(int id)
        {
            var orden = await _db.Ordenes
                .Include(o => o.OrdenDetalles)
                    .ThenInclude(d => d.Producto)
                .FirstOrDefaultAsync(o => o.IdOrden == id);

            if (orden == null) return NotFound($"La orden {id} no existe.");

            // Extraer IDs de categorías de los productos en la orden:
            var categoriaIds = orden.OrdenDetalles
                                    .Select(d => d.Producto.IdCategoria)
                                    .Distinct()
                                    .ToList();

            // Buscar en CategoriaProveedor los proveedores que vendan esas categorías:
            var query = await _db.CategoriaProveedores
                .Where(cp => categoriaIds.Contains(cp.IdCategoria) && cp.Estado == "Activo")
                .Select(cp => cp.Proveedor)
                .Distinct()
                .ToListAsync();

            // Mapear a un DTO sencillo:
            var result = query.Select(p => new
            {
                p.IdProveedor,
                p.Nombre,
                p.Ruc
            });

            return Ok(result);
        }
    }

    // ─────────── DTO para crear/actualizar Orden ───────────
    public class OrdenCreateDto
    {
        public string Estado { get; set; }  // Por ejemplo: "INCOMPLETA", "PENDIENTE", "COMPLETA"
        public List<OrdenDetalleCreateDto> OrdenDetalles { get; set; } = new();
    }

    public class OrdenDetalleCreateDto
    {
        public int IdProducto { get; set; }
        public int Cantidad { get; set; }
    }
}
