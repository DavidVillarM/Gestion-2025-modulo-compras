﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuloCompras.Data;
using ModuloCompras.DTOs;
using ModuloCompras.Models;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace ModuloCompras.Controllers
{
    [ApiController]
    [Route("api/ordenes/{ordenId}/detalles")]
    public class OrdenDetallesController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public OrdenDetallesController(ApplicationDbContext db) => _db = db;

        // GET: api/ordenes/{ordenId}/detalles
        [HttpGet]
        public async Task<IActionResult> GetAll(int ordenId)
        {
            var existeOrden = await _db.Ordenes.AnyAsync(o => o.IdOrden == ordenId);
            if (!existeOrden)
                return NotFound($"No existe la orden {ordenId}.");

            var detalles = await _db.OrdenDetalles
                                   .Where(d => d.IdOrden == ordenId)
                                   .Include(d => d.Producto)
                                   .ToListAsync();

            var result = detalles.Select(d => new OrdenDetalleReadDTO
            {
                IdOrdenDetalle = d.IdOrdenDetalle,
                IdProducto = d.IdProducto,
                Cantidad = d.Cantidad,
                NombreProducto = d.Producto != null ? d.Producto.Nombre : null
            }).ToList();

            return Ok(result);
        }

        // GET: api/ordenes/{ordenId}/detalles/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int ordenId, int id)
        {
            var detalle = await _db.OrdenDetalles
                                   .Include(d => d.Producto)
                                   .FirstOrDefaultAsync(d => d.IdOrdenDetalle == id && d.IdOrden == ordenId);
            if (detalle == null)
                return NotFound($"Detalle {id} no existe para la orden {ordenId}.");

            var dto = new OrdenDetalleReadDTO
            {
                IdOrdenDetalle = detalle.IdOrdenDetalle,
                IdProducto = detalle.IdProducto,
                Cantidad = detalle.Cantidad,
                NombreProducto = detalle.Producto != null ? detalle.Producto.Nombre : null
            };
            return Ok(dto);
        }

        // POST: api/ordenes/{ordenId}/detalles
        [HttpPost]
        public async Task<IActionResult> Create(int ordenId, [FromBody] OrdenDetalleCreateDTO dto)
        {
            var orden = await _db.Ordenes.FindAsync(ordenId);
            if (orden == null)
                return NotFound($"No existe la orden {ordenId}.");

            var entidad = new OrdenDetalle
            {
                IdOrden = ordenId,
                IdProducto = dto.IdProducto,
                Cantidad = dto.Cantidad
            };

            _db.OrdenDetalles.Add(entidad);
            await _db.SaveChangesAsync();

            var readDto = new OrdenDetalleReadDTO
            {
                IdOrdenDetalle = entidad.IdOrdenDetalle,
                IdProducto = entidad.IdProducto,
                Cantidad = entidad.Cantidad,
                NombreProducto = null
            };
            return CreatedAtAction(
                nameof(GetById),
                new { ordenId = ordenId, id = entidad.IdOrdenDetalle },
                readDto);
        }

        // PUT: api/ordenes/{ordenId}/detalles/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int ordenId, int id, [FromBody] OrdenDetalleCreateDTO dto)
        {
            var orden = await _db.Ordenes.FindAsync(ordenId);
            if (orden == null)
                return NotFound($"No existe la orden {ordenId}.");

            var entidad = await _db.OrdenDetalles
                                  .FirstOrDefaultAsync(d => d.IdOrdenDetalle == id && d.IdOrden == ordenId);
            if (entidad == null)
                return NotFound($"No existe la línea {id} para la orden {ordenId}.");

            entidad.IdProducto = dto.IdProducto;
            entidad.Cantidad = dto.Cantidad;
            await _db.SaveChangesAsync();

            return NoContent();
        }

        // DELETE: api/ordenes/{ordenId}/detalles/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int ordenId, int id)
        {
            var entidad = await _db.OrdenDetalles
                                  .FirstOrDefaultAsync(d => d.IdOrdenDetalle == id && d.IdOrden == ordenId);
            if (entidad == null)
                return NotFound($"No existe la línea {id} para la orden {ordenId}.");

            _db.OrdenDetalles.Remove(entidad);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
