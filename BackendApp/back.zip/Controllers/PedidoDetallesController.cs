﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ModuloCompras.Data;
using ModuloCompras.DTOs;
using ModuloCompras.Models;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;

namespace ModuloCompras.Controllers
{
    [ApiController]
    [Route("api/pedidos/{pedidoId}/detalles")]
    public class PedidoDetallesController : ControllerBase
    {
        private readonly ApplicationDbContext _db;
        public PedidoDetallesController(ApplicationDbContext db) => _db = db;

        // GET: api/pedidos/{pedidoId}/detalles
        [HttpGet]
        public async Task<IActionResult> GetAll(int pedidoId)
        {
            var existePedido = await _db.Pedidos.AnyAsync(p => p.IdPedido == pedidoId);
            if (!existePedido)
                return NotFound($"No existe el pedido {pedidoId}.");

            var detalles = await _db.PedidoDetalles
                                   .Where(d => d.IdPedido == pedidoId)
                                   .Include(d => d.Producto)
                                   .ToListAsync();

            var result = detalles.Select(d => new PedidoDetalleReadDTO
            {
                IdPedidoDetalle = d.IdPedidoDetalle,
                IdProducto = d.IdProducto,
                Cotizacion = d.Cotizacion,
                Cantidad = d.Cantidad,
                Iva = d.Iva,
                NombreProducto = d.Producto != null ? d.Producto.Nombre : null,
                NombreProveedor = null
            }).ToList();

            return Ok(result);
        }

        // GET: api/pedidos/{pedidoId}/detalles/{id}
        [HttpGet("{id}")]
        public async Task<IActionResult> GetById(int pedidoId, int id)
        {
            var detalle = await _db.PedidoDetalles
                                   .Include(d => d.Producto)
                                   .FirstOrDefaultAsync(d => d.IdPedidoDetalle == id && d.IdPedido == pedidoId);
            if (detalle == null)
                return NotFound($"Detalle {id} no existe para el pedido {pedidoId}.");

            var dto = new PedidoDetalleReadDTO
            {
                IdPedidoDetalle = detalle.IdPedidoDetalle,
                IdProducto = detalle.IdProducto,
                Cotizacion = detalle.Cotizacion,
                Cantidad = detalle.Cantidad,
                Iva = detalle.Iva,
                NombreProducto = detalle.Producto != null ? detalle.Producto.Nombre : null,
                NombreProveedor = null
            };
            return Ok(dto);
        }

        // POST: api/pedidos/{pedidoId}/detalles
        [HttpPost]
        public async Task<IActionResult> Create(int pedidoId, [FromBody] PedidoDetalleCreateDTO dto)
        {
            var pedido = await _db.Pedidos.FindAsync(pedidoId);
            if (pedido == null)
                return NotFound($"No existe el pedido {pedidoId}.");

            var entidad = new PedidoDetalle
            {
                IdPedido = pedidoId,
                IdProducto = dto.IdProducto,
                Cotizacion = dto.Cotizacion,
                Cantidad = dto.Cantidad,
                Iva = dto.Iva
            };

            _db.PedidoDetalles.Add(entidad);
            await _db.SaveChangesAsync();

            var readDto = new PedidoDetalleReadDTO
            {
                IdPedidoDetalle = entidad.IdPedidoDetalle,
                IdProducto = entidad.IdProducto,
                Cotizacion = entidad.Cotizacion,
                Cantidad = entidad.Cantidad,
                Iva = entidad.Iva,
                NombreProducto = null,
                NombreProveedor = null
            };

            return CreatedAtAction(
                nameof(GetById),
                new { pedidoId = pedidoId, id = entidad.IdPedidoDetalle },
                readDto);
        }

        // PUT: api/pedidos/{pedidoId}/detalles/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int pedidoId, int id, [FromBody] PedidoDetalleCreateDTO dto)
        {
            var pedido = await _db.Pedidos.FindAsync(pedidoId);
            if (pedido == null)
                return NotFound($"No existe el pedido {pedidoId}.");

            var entidad = await _db.PedidoDetalles
                                  .FirstOrDefaultAsync(d => d.IdPedidoDetalle == id && d.IdPedido == pedidoId);
            if (entidad == null)
                return NotFound($"No existe la línea {id} para el pedido {pedidoId}.");

            entidad.IdProducto = dto.IdProducto;
            entidad.Cotizacion = dto.Cotizacion;
            entidad.Cantidad = dto.Cantidad;
            entidad.Iva = dto.Iva;

            await _db.SaveChangesAsync();
            return NoContent();
        }

        // DELETE: api/pedidos/{pedidoId}/detalles/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int pedidoId, int id)
        {
            var entidad = await _db.PedidoDetalles
                                  .FirstOrDefaultAsync(d => d.IdPedidoDetalle == id && d.IdPedido == pedidoId);
            if (entidad == null)
                return NotFound($"No existe la línea {id} para el pedido {pedidoId}.");

            _db.PedidoDetalles.Remove(entidad);
            await _db.SaveChangesAsync();
            return NoContent();
        }
    }
}
